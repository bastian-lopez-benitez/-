#!/usr/bin/env python3
"""Deterministic dungeon rewards, exact explorer-map tags, and a bilingual 33-page codex.

Loot is scaled independently of spawner block-state compatibility. No chest can
supply the boss-exclusive Monstrous Upgrade Template, its heart, or Death Lord gear.
"""
from __future__ import annotations
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / 'src/main/resources'
CATALOG = [
 ('spectrite_crypt',1,'overworld','Cripta prismática','Prismatic Crypt','Cámaras de piedra y trampas de iniciación.','Stone chambers and introductory traps.'),
 ('spectrite_catacombs',2,'overworld','Catacumbas de Spectrita','Spectrite Catacombs','Galerías profundas, suelos falsos y guardianes encantados.','Deep galleries, false floors and enchanted guardians.'),
 ('spectrite_sanctum',3,'overworld','Santuario prismático','Prismatic Sanctum','Combate contra guardianes equipados con Spectrita.','Face guardians equipped with Spectrite.'),
 ('spectrite_prismatic_vault',4,'overworld','Bóveda prismática','Prismatic Vault','Cámaras selladas, acertijos y el Coloso prismático.','Sealed rooms, puzzles and the Prismatic Colossus.'),
 ('spectrite_prism_mines',1,'overworld','Minas del Prisma','Prism Mines','Galerías mineras, fosos y depósitos de fragmentos.','Mine galleries, pits and fragment deposits.'),
 ('spectrite_drowned_archive',2,'overworld','Archivo Sumergido','Drowned Archive','Archivos subterráneos, rutas laterales y trampas.','Underground archives, side routes and traps.'),
 ('spectrite_thorn_citadel',3,'overworld','Ciudadela de las Espinas','Thorn Citadel','Patios encadenados, varias plantas y emboscadas.','Linked courtyards, multiple floors and ambushes.'),
 ('spectrite_eclipse_observatory',3,'overworld','Observatorio del Eclipse','Eclipse Observatory','Recorre galerías extensas y protege tu retirada.','Explore extensive galleries and protect your retreat.'),
 ('spectrite_soul_necropolis',4,'overworld','Necrópolis de las Almas','Soul Necropolis','Una ciudad funeraria con equipo de Netherita Spectrita.','A burial city guarded by Netherite Spectrite equipment.'),
 ('spectrite_monstrous_foundry',5,'overworld','Fundición Monstruosa','Monstrous Foundry','La mayor mazmorra: cuatro niveles, trampas y la Monstruosidad.','The largest dungeon: four levels, traps and the Monstrosity.'),
 ('spectrite_cinder_cistern',2,'the_nether','Cisterna de las Cenizas','Cinder Cistern','Una expedición extremadamente rara del Nether.','An extremely rare expedition in the Nether.'),
 ('spectrite_basalt_bastion',3,'the_nether','Bastión de Basalto','Basalt Bastion','Galerías fortificadas entre ceniza y basalto.','Fortified galleries among ash and basalt.'),
 ('spectrite_soul_crucible',3,'the_nether','Crisol de las Almas','Soul Crucible','Tres niveles de trampas y guardianes de Spectrita.','Three floors of traps and Spectrite guardians.'),
 ('spectrite_infernal_archive',4,'the_nether','Archivo Infernal','Infernal Archive','Un archivo remoto con defensas de Netherita Spectrita.','A remote archive defended with Netherite Spectrite.'),
 ('spectrite_netherite_colossus',4,'the_nether','Baluarte del Coloso de Netherita','Netherite Colossus Hold','Fortaleza de élite con tres niveles y trampas avanzadas.','An elite fortress with three floors and advanced traps.'),
 ('spectrite_obsidian_labyrinth', 5, 'overworld', 'Laberinto de Obsidiana', 'Obsidian Labyrinth', 'Cuatro plantas de corredores fracturados y trampas cruzadas.', 'Four floors of fractured corridors and crossfire traps.'),
 ('spectrite_shattered_cathedral', 5, 'overworld', 'Catedral Quebrada', 'Shattered Cathedral', 'Una catedral de cuarzo y Spectrita, defensores y fosos encadenados.', 'A quartz and Spectrite cathedral with defenders and linked pits.'),
 ('spectrite_abyssal_panopticon', 5, 'overworld', 'Panóptico Abisal', 'Abyssal Panopticon', 'Prisiones profundas, emboscadas y cámaras de vigilancia.', 'Deep prisons, ambushes and surveillance chambers.'),
 ('spectrite_clockwork_tomb', 5, 'overworld', 'Sepulcro del Relojero', 'Clockwork Tomb', 'Cobre antiguo y trampas de proyectiles, pociones y suelos falsos.', 'Ancient copper and projectile, potion and false-floor traps.'),
 ('spectrite_crown_of_ruin', 5, 'overworld', 'Corona de la Ruina', 'Crown of Ruin', 'Cuatro niveles de piedra del End y guardianes de élite.', 'Four floors of End stone and elite guardians.'),
 ('spectrite_infernal_gauntlet', 4, 'the_nether', 'Prueba Infernal', 'Infernal Gauntlet', 'Tres niveles con fuego cruzado y trampas en rutas alternativas.', 'Three floors with crossfire and traps on alternate routes.'),
 ('spectrite_magma_labyrinth', 4, 'the_nether', 'Laberinto del Magma', 'Magma Labyrinth', 'Cubos de magma de Spectrita y depósitos de cristales entre el basalto.', 'Spectrite magma cubes and crystal deposits among basalt.'),
 ('spectrite_sepulchral_chains', 4, 'the_nether', 'Cadenas Sepulcrales', 'Sepulchral Chains', 'Cuatro niveles de hueso y suelo de almas, fosos y guardianes.', 'Four floors of bone and soul soil, pits and guardians.'),
 ('spectrite_hellfire_citadel', 5, 'the_nether', 'Ciudadela del Fuego Eterno', 'Hellfire Citadel', 'Expedición de grado V, cuatro plantas y trampas numerosas.', 'Grade V expedition with four floors and numerous traps.'),
 ('spectrite_nether_eclipse', 5, 'the_nether', 'Eclipse del Nether', 'Nether Eclipse', 'Una remota fortaleza de obsidiana, brutos y defensas encantadas.', 'A remote obsidian fortress, brutes and enchanted defenses.'),
 ('spectrite_prism_reef', 2, 'ocean', 'Arrecife del Prisma', 'Prism Reef', 'Cinco santuarios de coral conectados por canales de guardianes.', 'Five coral shrines linked by guardian channels.'),
 ('spectrite_sunken_basilica', 3, 'ocean', 'Basílica Sumergida', 'Sunken Basilica', 'Naves de cuarzo en dos niveles inundados y campanas de aire.', 'Two flooded floors of quartz naves and air bells.'),
 ('spectrite_abyssal_reliquary', 4, 'ocean', 'Relicario Abisal', 'Abyssal Reliquary', 'Un anillo de cámaras oscuras rodea un relicario defendido.', 'A ring of dark chambers surrounds a guarded reliquary.'),
 ('spectrite_tidal_citadel', 4, 'ocean', 'Ciudadela de las Mareas', 'Tidal Citadel', 'Bastiones de cobre, trampas de burbujas y rutas verticales.', 'Copper bastions, bubble traps and vertical routes.'),
 ('spectrite_leviathan_sanctum', 5, 'ocean', 'Santuario del Leviatán', 'Leviathan Sanctum', 'Tres niveles abisales y un arconte marino de Spectrita.', 'Three abyssal floors and a Spectrite sea archon.'),
]
ROMAN = ['', 'I','II','III','IV','V']

def write(relative, data):
 p=RES/relative;p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def uniform(lo,hi):
 return {'type':'minecraft:uniform','min':lo,'max':hi}

def item(name,weight=1,lo=1,hi=1,*functions):
 result={'type':'minecraft:item','name':name,'weight':weight}
 fn=([{'function':'minecraft:set_count','count':uniform(lo,hi)}] if (lo,hi)!=(1,1) else [])+list(functions)
 if fn:result['functions']=fn
 return result

def pool(rolls, entries, chance=None):
 result={'rolls':rolls,'bonus_rolls':0,'entries':entries}
 if chance is not None: result['conditions']=[{'condition':'minecraft:random_chance','chance':chance}]
 return result

def enchanted(lo,hi):
 return {'function':'minecraft:enchant_with_levels','levels':uniform(lo,hi)}

WORN={'function':'minecraft:set_damage','damage':uniform(.35,.75)}
THEME={
 'spectrite_crypt':('minecraft:bone',3,8), 'spectrite_catacombs':('minecraft:gold_ingot',2,5),
 'spectrite_sanctum':('minecraft:amethyst_shard',6,12), 'spectrite_prismatic_vault':('minecraft:diamond',2,4),
 'spectrite_prism_mines':('minecraft:raw_gold',4,9), 'spectrite_drowned_archive':('minecraft:prismarine_crystals',3,7),
 'spectrite_thorn_citadel':('minecraft:emerald',3,7), 'spectrite_eclipse_observatory':('minecraft:echo_shard',1,2),
 'spectrite_soul_necropolis':('minecraft:echo_shard',2,4), 'spectrite_monstrous_foundry':('minecraft:netherite_scrap',2,4),
 'spectrite_cinder_cistern':('minecraft:quartz',6,12), 'spectrite_basalt_bastion':('minecraft:gold_ingot',3,6),
 'spectrite_soul_crucible':('minecraft:ghast_tear',1,2), 'spectrite_infernal_archive':('minecraft:netherite_scrap',1,2),
 'spectrite_netherite_colossus':('minecraft:netherite_scrap',2,3),
}

def common(rank):
 frag='spectrite:spectrite_gem_fragment'
 if rank==1:
  return [item(frag,16,1,4),item('minecraft:iron_ingot',10,1,3),item('minecraft:bread',12,1,3),item('minecraft:arrow',10,4,10),item('minecraft:coal',8,2,5)]
 result=[item(frag,14,rank,rank+4),item('spectrite:spectrite_dust',10,2,rank+2),item('minecraft:experience_bottle',8,1,rank+1),item('minecraft:gold_ingot',8,1,rank),item('spectrite:spectrite_arrow',10,4,8+rank*2)]
 if rank>=2: result += [item('spectrite:spectrite_gem',max(2,rank*2),1,max(1,rank-1)),item('minecraft:diamond',5,1,max(1,rank-1))]
 if rank>=3: result += [item('spectrite:spectrite_arrow_special',6,2,4+rank),item('spectrite:spectrite_apple',5)]
 if rank>=4: result += [item('minecraft:netherite_scrap',3),item('minecraft:golden_apple',4,1,2)]
 return result

def rewards(name,rank,treasure):
 entries=common(rank)+[item(*((THEME.get(name,('minecraft:netherite_scrap',2,4))[0],6,THEME.get(name,('minecraft:netherite_scrap',2,4))[1],THEME.get(name,('minecraft:netherite_scrap',2,4))[2])))]
 rolls=uniform((3 if treasure else 1)+rank//2,(5 if treasure else 3)+rank//2)
 pools=[pool(rolls,entries)]
 if treasure:
  # Guaranteed supplies, not guaranteed equipment. Worn gear cannot skip the next forge upgrade.
  pools.append(pool(1,[item('minecraft:book',1,1,1,enchanted(5+rank*4,min(30,10+rank*5)))]))
  pools.append(pool(1,[item('spectrite:prismatic_codex')],.25 if rank==1 else .08))
  if rank<=2:
   equipment=[item('spectrite:spectrite_chainmail_'+piece,1,1,1,enchanted(3+rank*3,8+rank*4),WORN) for piece in ('helmet','chestplate','leggings','boots')]
   pools.append(pool(1,equipment,.40 if rank==1 else .60))
  elif rank==3:
   equipment=[item('spectrite:spectrite_'+piece,1,1,1,enchanted(12,22),WORN) for piece in ('sword','pickaxe','helmet','boots')]
   pools.append(pool(1,equipment,.40))
  else:
   equipment=[item('spectrite:netherite_spectrite_'+piece,1,1,1,enchanted(20,30),WORN) for piece in ('sword','pickaxe','helmet','boots')]
   pools.append(pool(1,equipment,.25 if rank==4 else .45))
   pools.append(pool(1,[item('spectrite:netherite_spectrite_upgrade_smithing_template')],.10 if rank==4 else .20))
   pools.append(pool(1,[item('spectrite:soul_ingot',1,1,2 if rank==4 else 3)],.35 if rank==4 else .65))
   pools.append(pool(1,[item('spectrite:active_soul_ingot')],.08 if rank==4 else .18))
   pools.append(pool(1,[item('spectrite:soul_upgrade_smithing_template')],.04 if rank==4 else .10))
 return pools


def generate():
 for name,rank,dimension,es,en,desc_es,desc_en in CATALOG:
  write(f'data/spectrite/tags/worldgen/structure/maps/{name}.json',{'replace':False,'values':['spectrite:'+name]})
  for suffix,treasure in [('spawner',False),('treasure',True)]:
   path='chests/dungeons/'+name+'_'+suffix
   write('data/spectrite/loot_table/'+path+'.json',{'type':'minecraft:chest','random_sequence':'spectrite:'+path,'pools':rewards(name,rank,treasure)})
 # Only the foundry uses these. No unbounded hard-control or damage amplification in a repeating trap.
 for suffix,entries in [
  ('arrows',[item('spectrite:spectrite_arrow_special',2,3,5),item('spectrite:spectrite_arrow',3,4,7)]),
  ('potions',[item('minecraft:splash_potion',2,1,1,{'function':'minecraft:set_potion','id':'minecraft:poison'}),item('minecraft:splash_potion',1,1,1,{'function':'minecraft:set_potion','id':'minecraft:weakness'})])]:
  path='dispensers/dungeon_monster_'+suffix
  write('data/spectrite/loot_table/'+path+'.json',{'type':'minecraft:chest','random_sequence':'spectrite:'+path,'pools':[pool(uniform(1,2),entries)]})
 lang={
  'en':{'map.spectrite.dungeon_title':'%s · Difficulty %s','map.spectrite.dimension':'Dimension: %s','map.spectrite.difficulty':'Difficulty: %s / V','map.spectrite.coordinates':'Destination: X %s, Z %s','map.spectrite.nether':'The Nether','map.spectrite.overworld':'Overworld','map.spectrite.nether_hint':'Read this chart inside the Nether. Coordinates are Nether coordinates.','map.spectrite.explore_hint':'The marker points to a real structure; the entrance may be underground.'},
  'es':{'map.spectrite.dungeon_title':'%s · Dificultad %s','map.spectrite.dimension':'Dimensión: %s','map.spectrite.difficulty':'Dificultad: %s / V','map.spectrite.coordinates':'Destino: X %s, Z %s','map.spectrite.nether':'Nether','map.spectrite.overworld':'Mundo Normal','map.spectrite.nether_hint':'Lee este mapa dentro del Nether. Sus coordenadas pertenecen al Nether.','map.spectrite.explore_hint':'La marca señala una estructura real; la entrada puede ser subterránea.'},
 }
 for i,(name,rank,dimension,es,en,desc_es,desc_en) in enumerate(CATALOG,17):
  for locale,title,desc in [('es',es,desc_es),('en',en,desc_en)]:
   lang[locale]['structure.spectrite.'+name]=title
   dim=('Nether' if dimension=='the_nether' else ('Mundo Normal' if locale=='es' else 'Overworld'))
   summary=('Equipo y botín mejoran con la dificultad. El cartógrafo vende mapas con el destino real.' if locale=='es' else 'Equipment and rewards scale with difficulty. Cartographers sell charts to real destinations.')
   champions=json.loads((ROOT/'tools/monstrous_champions_lang.json').read_text())
   boss=champions['es_es' if locale=='es' else 'en_us'].get('boss.spectrite.'+name,'')
   summary=('Jefe: ' if locale=='es' else 'Champion: ')+boss+('\nLos ataques anuncian su zona: esquiva antes del impacto.' if locale=='es' else '\nAttacks mark their area: dodge before impact.')
   lang[locale]['codex.spectrite.page.'+str(i)]=f'§l{title}§r\n\n{ROMAN[rank]} / V · {dim}\n\n{desc}\n\n{summary}'
 lang['es'].update({
  'codex.spectrite.page.2':'§lLos tiers§r\n\n1. Cota de mallas\n2. Spectrita\n3. Netherita Spectrita\n4. Almas Espectrales\n5. Señor de la Muerte\n\nLos dos últimos requieren la Forja del Réquiem.',
  'codex.spectrite.page.5':'§lVeinticinco mazmorras§r\n\nQuince terrestres del Mundo Normal, cinco monumentos oceánicos y diez extremadamente raras del Nether. Las más difíciles tienen hasta cuatro plantas y numerosas trampas. Dificultad I–V. Los cartógrafos mejoran su oferta al subir de nivel. Los maestros venden mapas del Nether y de la Fundición Monstruosa.',
  'codex.spectrite.page.7':'§lSpawners§r\n\nSus guardianes mejoran el equipo según la dificultad. Los spawners tienen un límite de nacimientos y sus criaturas dan materiales según su peligro, pero no su equipo: explora y rompe los generadores para reclamar sus recursos.',
  'codex.spectrite.page.47':'§lForja del Réquiem§r\n\nLa mesa avanzada mejora Netherita Spectrita a Almas Espectrales. Para Señor de la Muerte: equipo de Almas Espectrales + Molde de mejora monstruosa + Esencia de los no muertos. Conserva sus encantamientos.',
  'codex.spectrite.page.48':'§lLa Monstruosidad§r\n\nLa Fundición Monstruosa es de grado V. El golem de netherita y Spectrita anuncia sus ataques. Salta sobre las ondas y evita las zonas marcadas. Solo el jefe entrega su corazón y el Molde monstruoso. Los cofres nunca los sustituyen.',
 })
 lang['en'].update({
  'codex.spectrite.page.2':'§lThe tiers§r\n\n1. Spectrite chainmail\n2. Spectrite\n3. Netherite Spectrite\n4. Spectral Souls\n5. Death Lord\n\nThe final two require the Requiem Forge.',
  'codex.spectrite.page.5':'§lTwenty-five dungeons§r\n\nFifteen land expeditions, five ocean monuments and ten extremely rare Nether expeditions. Harder expeditions have up to four floors and many traps. Difficulty I–V. Cartographer offers improve with their level. Masters sell Nether and Monstrous Foundry charts.',
  'codex.spectrite.page.7':'§lSpawners§r\n\nGuardian equipment scales with difficulty. Spawners have a finite spawn budget and their creatures reward danger with materials, never equipped upgrade gear. Explore and break the generators to claim their resources.',
  'codex.spectrite.page.47':'§lRequiem Forge§r\n\nThe advanced station upgrades Netherite Spectrite into Spectral Souls. For Death Lord: Spectral Soul equipment + Monstrous Upgrade Template + Undead Essence. Earned enchantments are retained.',
  'codex.spectrite.page.48':'§lThe Monstrosity§r\n\nThe Monstrous Foundry is grade V. Its netherite and Spectrite golem telegraphs attacks. Jump over shockwaves and avoid marked zones. Only the boss drops its heart and Monstrous Template. No chest replaces this fight.',
 })
 (ROOT/'tools/dungeons_guide_lang.json').write_text(json.dumps(lang,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 for path in (RES/'assets/spectrite/lang').glob('*.json'):
  data=json.loads(path.read_text(encoding='utf-8')); data.update(lang['es' if path.stem.startswith('es_') else 'en']);path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print('30 exact explorer-map tags, 60 ranked chest tables, 2 foundry traps, 48-page codex generated')

if __name__=='__main__': generate()
