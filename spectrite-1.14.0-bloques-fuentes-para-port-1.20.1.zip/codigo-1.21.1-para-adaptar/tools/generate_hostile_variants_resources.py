#!/usr/bin/env python3
"""Complete hostile species catalog, player-credit danger rewards and crystal architecture."""
from pathlib import Path
import json,re,zipfile
ROOT=Path(__file__).resolve().parents[1];RES=ROOT/'src/main/resources'
def write(path,data):
 p=RES/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
def item(name,count=1):
 d={'type':'minecraft:item','name':name}
 if count!=1:d['functions']=[{'function':'minecraft:set_count','count':count}]
 return d
def pool(name,chance,lo,hi):
 return {'rolls':1,'conditions':[{'condition':'minecraft:killed_by_player'},{'condition':'minecraft:random_chance','chance':chance}],
 'entries':[item(name,{'type':'minecraft:uniform','min':lo,'max':hi})]}
def box(a,b,texture='prism',rotation=None):
 d={'from':a,'to':b,'faces':{side:{'uv':[0,0,16,16],'texture':'#'+texture} for side in ['north','south','east','west','up','down']}}
 if rotation:d['rotation']=rotation
 return d
def generate():
 write("data/spectrite/damage_type/prismatic_mob_skill.json",{"exhaustion":.1,"message_id":"spectrite.prismatic_mob_skill","scaling":"when_caused_by_living_non_player"})
 source=(ROOT/'src/main/java/com/samuel/spectrite/souls/monster/SpectriteHostileVariants.java').read_text()
 catalog=re.findall(r'add\("([a-z_]+)",EntityType.[A-Z_]+,(\d+),(\d+),(true|false)\);',source)
 es={'magma_cube':'Cubo de magma','bogged':'Esqueleto cenagoso','breeze':'Brisa','cave_spider':'Araña de cueva','elder_guardian':'Guardián anciano','ender_dragon':'Dragón del End','evoker':'Evocador','giant':'Gigante','guardian':'Guardián','illusioner':'Ilusionista','phantom':'Fantasma','pillager':'Saqueador','ravager':'Devastador','shulker':'Shulker','spider':'Araña','stray':'Esqueleto glacial','vex':'Ánima','vindicator':'Vindicador','warden':'Warden','witch':'Bruja','zoglin':'Zoglin','zombie_villager':'Aldeano zombi','zombified_piglin':'Piglin zombificado'}
 lang={'es_es':{},'en_us':{}}
 with zipfile.ZipFile(ROOT/'libs/spectrite-1.21.1-1.9.0-pre1-almas.jar') as base:
  for name,rank,danger,added in catalog:
   rank,danger=int(rank),int(danger);path=f'data/spectrite/loot_table/entities/spectrite_{name}.json'
   # Preserve exact original ingredients (including the independently fixed 5% enderman orb).
   out=RES/path
   if added=='false':
    data=json.loads(out.read_text()) if name=='enderman' and out.exists() else json.loads(base.read(path))
    data['pools']=[p for p in data.get('pools',[]) if not p.get('spectrite_danger_reward',False)]
   else:
    entry=item('minecraft:rotten_flesh',{'type':'minecraft:uniform','min':1,'max':3}) if name in ('giant','illusioner') else {'type':'minecraft:loot_table','value':'minecraft:entities/'+name}
    data={'type':'minecraft:entity','pools':[{'rolls':1,'entries':[entry]}]}
   data['random_sequence']='spectrite:entities/spectrite_'+name
   # All additional rewards require credited kills; no looting multiplier on progression materials.
   data['pools'].append(pool('spectrite:spectrite_gem_fragment',min(.95,.15+.1*danger),max(1,danger//2),danger+1))
   if danger>=2:data['pools'].append(pool('spectrite:spectrite_dust',min(.65,.06*danger),1,max(1,danger//2)))
   if danger>=3:data['pools'].append(pool('spectrite:spectrite_gem',min(.45,.035*danger),1,max(1,danger//3)))
   if danger>=5:data['pools'].append(pool('spectrite:soul_ingot',min(.35,.025*danger),1,2))
   if danger>=8:data['pools'].append(pool('spectrite:active_soul_ingot',.08,1,1))
   write(path,data)
   if added=='true':
    write(f'assets/spectrite/models/item/spectrite_{name}_spawn_egg.json',{'parent':'minecraft:item/template_spawn_egg'})
    for locale in lang:
     title=(es[name]+' de Spectrita') if locale=='es_es' else ('Spectrite '+name.replace('_',' ').title())
     lang[locale]['entity.spectrite.spectrite_'+name]=title
     lang[locale]['item.spectrite.spectrite_'+name+'_spawn_egg']=('Generador de '+title if locale=='es_es' else title+' Spawn Egg')
  fortress=json.loads(base.read('data/spectrite/worldgen/structure/spectrite_fortress.json'))
  fortress['spawn_overrides']['monster']['spawns'] += [{'type':'spectrite:spectrite_'+n,'weight':w,'minCount':1,'maxCount':2} for n,w in [('magma_cube',14),('blaze',10),('zoglin',5),('zombified_piglin',8)]]
  write('data/spectrite/worldgen/structure/spectrite_fortress.json',fortress)
 names={'spectrite_fragment_mosaic':('Mosaico de fragmentos de Spectrita','Spectrite Fragment Mosaic'),'spectrite_fragment_bricks':('Relieve de fragmentos de Spectrita','Spectrite Fragment Relief'),'spectrite_fragment_tiles':('Baldosas de fragmentos de Spectrita','Spectrite Fragment Tiles'),'fractured_spectrite_pillar':('Pilar fracturado de Spectrita','Fractured Spectrite Pillar'),'spectrite_fragment_cluster':('Cúmulo de fragmentos de Spectrita','Spectrite Fragment Cluster'),'spectrite_fragment_reliquary':('Relicario de fragmentos de Spectrita','Spectrite Fragment Reliquary')}
 for name,titles in names.items():
  elements=[]
  if name.endswith(('mosaic','bricks','tiles')):
   elements=[box([.1,0,.1],[15.9,15.8,15.9],'stone')]
   for x in range(4):
    for z in range(4):
     elements.append(box([x*4+.4,15.85,z*4+.4],[x*4+3.6,16,z*4+3.6]))
   if name.endswith('tiles'):
    elements=[box([.1,0,.1],[15.9,15.8,15.9],'stone')]
    for x in range(3):
     for z in range(3):
      cx=2.7+x*5.3;cz=2.7+z*5.3
      elements.append(box([cx-1.6,15.85,cz-1.6],[cx+1.6,16,cz+1.6],rotation={'origin':[cx,15.9,cz],'axis':'y','angle':45}))
   if name.endswith('bricks'):
    for y in range(4):
     for x in range(4):elements += [box([x*4+.3,y*4+.4,0],[x*4+3.7,y*4+3.6,.3]),box([x*4+.3,y*4+.4,15.7],[x*4+3.7,y*4+3.6,16])]
  elif name.endswith('pillar'):
   elements=[box([2,0,2],[14,3,14],'stone'),box([4,3,4],[12,14,12],'stone'),box([2,14,2],[14,16,14],'stone')]
   for y in range(3):
    for x,z in [(3,3),(10,3),(3,10),(10,10)]:elements.append(box([x,y*4+2,z],[x+3,y*4+6,z+3],rotation={'origin':[8,8,8],'axis':'y','angle':22.5 if y%2==0 else -22.5}))
  else:
   elements=[box([1,0,1],[15,3,15],'stone')]
   for i,(x,z,h) in enumerate([(3,3,9),(8,2,13),(11,7,11),(7,10,15),(2,10,8),(6,6,14)]):
    elements += [box([x,3,z],[x+2,h,z+2],rotation={'origin':[x+1,3,z+1],'axis':'z','angle':22.5 if i%2 else -22.5}),box([x+.3,h-.8,z+.3],[x+1.7,h+1,z+1.7])]
   if name.endswith('reliquary'):elements += [box([1,3,1],[3,13,3],'stone'),box([13,3,13],[15,13,15],'stone'),box([1,13,1],[15,15,15],'stone')]
  write(f'assets/spectrite/models/block/{name}.json',{'parent':'minecraft:block/block','ambientocclusion':True,'textures':{'particle':'spectrite:block/spectrite_block_ns','prism':'spectrite:block/spectrite_block_ns','stone':'minecraft:block/polished_deepslate'},'elements':elements})
  write(f'assets/spectrite/blockstates/{name}.json',{'variants':{'':{'model':'spectrite:block/'+name}}})
  write(f'assets/spectrite/models/item/{name}.json',{'parent':'spectrite:block/'+name})
  write(f'data/spectrite/loot_table/blocks/{name}.json',{'type':'minecraft:block','pools':[{'rolls':1,'conditions':[{'condition':'minecraft:survives_explosion'}],'entries':[item('spectrite:'+name)]}]})
  write(f'data/spectrite/recipe/{name}.json',{'type':'minecraft:crafting_shaped','pattern':[' F ','FSF',' F '],'key':{'F':{'item':'spectrite:spectrite_gem_fragment'},'S':{'item':'minecraft:deepslate' if name.endswith('mosaic') else 'spectrite:spectrite_fragment_mosaic'}},'result':{'id':'spectrite:'+name,'count':4 if name.endswith('mosaic') else 2}})
  for locale,title in zip(lang,titles):lang[locale]['block.spectrite.'+name]=title
 write('data/minecraft/tags/block/mineable/pickaxe.json',{'replace':False,'values':['spectrite:'+n for n in names]})
 for locale in lang:
  lang[locale]['effect.spectrite.fractured_resistance']='Resistencia fracturada' if locale=='es_es' else 'Fractured Resistance'
  lang[locale]['effect.spectrite.fractured_resistance.description']='Las armas de Spectrita ignoran el 20 % de tu armadura durante 6 s. Se renueva, no se acumula.' if locale=='es_es' else 'Spectrite weapons ignore 20% of your armor for 6 s. Refreshes, never stacks.'
 (ROOT/'tools/monstrous_hostiles_lang.json').write_text(json.dumps(lang,ensure_ascii=False,indent=2)+'\n')
 (ROOT/'build/hostile-reward-catalog.json').write_text(json.dumps([{'species':n,'minimum_difficulty':int(r),'danger':int(d),'new_variant':a=='true'} for n,r,d,a in catalog],indent=2)+'\n')
 print(f'{len(catalog)} hostile counterparts, ranked kill rewards, fortress magma cubes and six sculpted fragment blocks generated.')
if __name__=='__main__':generate()
