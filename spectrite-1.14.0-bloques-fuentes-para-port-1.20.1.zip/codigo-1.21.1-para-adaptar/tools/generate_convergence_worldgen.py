#!/usr/bin/env python3
"""Fifteen dimension-aware dungeon registrations share two sparse placement sets."""
from pathlib import Path
import json,runpy
ROOT=Path(__file__).resolve().parents[1]
RES=ROOT/'src/main/resources'

def write(path,data):
    out=RES/path;out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')

def generate():
    catalog=runpy.run_path(str(ROOT/'tools/generate_dungeon_guide_resources.py'))['CATALOG']
    tiers={1:'basic',2:'intermediate',3:'advanced',4:'legendary',5:'legendary'}
    ids=[];sets={'overworld':[],'the_nether':[],'ocean':[]}
    weights={1:18,2:14,3:8,4:4,5:1}
    for name,rank,dim,*_ in catalog:
        ids.append('spectrite:'+name)
        write(f'data/spectrite/worldgen/structure/{name}.json',{
            'type':'spectrite:spectral_dungeon','tier':tiers[rank],'profile':name,
            'biomes':'#minecraft:is_nether' if dim=='the_nether' else '#minecraft:is_ocean' if dim=='ocean' else '#spectrite:has_structure/spectrite_dungeon',
            'step':'underground_structures','spawn_overrides':{},'terrain_adaptation':'none'})
        sets[dim].append({'structure':'spectrite:'+name,'weight':weights[rank]})
    for dim,entries in sets.items():
        nether=dim=='the_nether';ocean=dim=='ocean'
        write('data/spectrite/worldgen/structure_set/'+('spectrite_nether_dungeons' if nether else 'spectrite_ocean_monuments' if ocean else 'spectrite_dungeons')+'.json',{
            'structures':entries,'placement':{'type':'minecraft:random_spread','spacing':160 if nether else 96 if ocean else 64,
            'separation':80 if nether else 48 if ocean else 32,'salt':938265047 if nether else 938265048 if ocean else 938265046,
            'frequency':.15 if nether else .25 if ocean else .65,'frequency_reduction_method':'default','spread_type':'linear'}})
    for tag in ('spectrite_dungeons','on_dungeon_maps'):
        write('data/spectrite/tags/worldgen/structure/'+tag+'.json',{'replace':False,'values':ids})
    print('Registered 25 land dungeons and 5 ocean monuments; three sparse placement sets.')

if __name__=='__main__':generate()
