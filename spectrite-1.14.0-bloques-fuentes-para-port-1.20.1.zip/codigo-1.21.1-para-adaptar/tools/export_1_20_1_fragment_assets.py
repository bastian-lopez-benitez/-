#!/usr/bin/env python3
"""Export reusable block data, explicitly NOT an executable Forge port."""
from pathlib import Path
import json,zipfile
ROOT=Path(__file__).resolve().parents[1]
RES=ROOT/'src/main/resources'
NAMES='spectrite_fragment_mosaic spectrite_fragment_bricks spectrite_fragment_tiles fractured_spectrite_pillar spectrite_fragment_cluster spectrite_fragment_reliquary'.split()
def generate():
    output=ROOT/'build/port-1.20.1-fragment-assets.zip'
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as out:
        out.writestr('pack.mcmeta',json.dumps({'pack':{'pack_format':15,'description':'Spectrite fragments: reusable 1.20.1 resources; requires the Forge code port'}}))
        for name in NAMES:
            for kind in ('models/block','models/item','blockstates'):
                path=f'assets/spectrite/{kind}/{name}.json';out.writestr(path,(RES/path).read_bytes())
            for old,new in [('recipe','recipes'),('loot_table/blocks','loot_tables/blocks')]:
                path=f'data/spectrite/{old}/{name}.json';data=json.loads((RES/path).read_text())
                if old=='recipe':data['result']['item']=data['result'].pop('id')
                out.writestr(f'data/spectrite/{new}/{name}.json',json.dumps(data,indent=2))
        out.writestr('data/minecraft/tags/blocks/mineable/pickaxe.json',json.dumps({'replace':False,'values':['spectrite:'+n for n in NAMES]}))
        with zipfile.ZipFile(ROOT/'libs/spectrite-1.21.1-1.9.0-pre1-almas.jar') as original:
            for suffix in ('.png','.png.mcmeta'):
                path='assets/spectrite/textures/block/spectrite_block_ns'+suffix;out.writestr(path,original.read(path))
        for locale in ('es_es','en_us'):
            data=json.loads((RES/f'assets/spectrite/lang/{locale}.json').read_text())
            out.writestr(f'assets/spectrite/lang/{locale}.json',json.dumps({k:v for k,v in data.items() if k in ['block.spectrite.'+n for n in NAMES]},ensure_ascii=False))
        out.writestr('PORT_README.md',(ROOT/'PORT_1_20_1.md').read_bytes())
        for relative in (
            'src/main/java/com/samuel/spectrite/souls/dungeon/DungeonFragmentBlocks.java',
            'src/main/java/com/samuel/spectrite/souls/dungeon/DungeonCell.java',
            'src/main/java/com/samuel/spectrite/souls/dungeon/DungeonPalette.java',
            'src/main/java/com/samuel/spectrite/souls/dungeon/DungeonLayout.java',
            'src/main/java/com/samuel/spectrite/souls/dungeon/DungeonProfile.java',
            'tools/generate_hostile_variants_resources.py',
            'tools/generate_convergence_worldgen.py',
            'tools/generate_dungeon_guide_resources.py',
            'tools/export_1_20_1_fragment_assets.py',
        ):
            out.writestr('codigo-1.21.1-para-adaptar/'+relative,(ROOT/relative).read_bytes())
    print(output)
if __name__=='__main__':generate()
