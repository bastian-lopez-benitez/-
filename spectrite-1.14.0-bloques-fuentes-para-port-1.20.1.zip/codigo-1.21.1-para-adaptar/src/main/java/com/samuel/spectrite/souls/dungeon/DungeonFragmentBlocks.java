package com.samuel.spectrite.souls.dungeon;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.neoforge.registries.DeferredBlock;

/** Sculpted fragments retain the uploaded mod's original animated Spectrite surfaces. */
public final class DungeonFragmentBlocks {
    public static final Map<String,DeferredBlock<Block>> BLOCKS=new LinkedHashMap<>();
    public static final DeferredBlock<Block> MOSAIC=add("spectrite_fragment_mosaic",false);
    public static final DeferredBlock<Block> BRICKS=add("spectrite_fragment_bricks",false);
    public static final DeferredBlock<Block> TILES=add("spectrite_fragment_tiles",false);
    public static final DeferredBlock<Block> PILLAR=add("fractured_spectrite_pillar",true);
    public static final DeferredBlock<Block> CLUSTER=add("spectrite_fragment_cluster",true);
    public static final DeferredBlock<Block> RELIQUARY=add("spectrite_fragment_reliquary",true);
    private static DeferredBlock<Block> add(String name,boolean sculpted) {
        var block=SpectralDungeons.BLOCKS.register(name,()->{
            var properties=BlockBehaviour.Properties.ofFullCopy(Blocks.DEEPSLATE_BRICKS).strength(4.5F,15F).lightLevel(s->sculpted?4:1);
            if(sculpted)properties.noOcclusion();
            return new Block(properties);
        });
        SpectralDungeons.ITEMS.registerSimpleBlockItem(block);BLOCKS.put(name,block);return block;
    }
    static void bootstrap(){}
    private DungeonFragmentBlocks(){}
}
