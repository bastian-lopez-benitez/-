package com.samuel.spectrite.souls.dungeon;

import com.samuel.spectrite.init.SpectriteBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CandleBlock;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.PointedDripstoneBlock;
import net.minecraft.world.level.block.SkullBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DripstoneThickness;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.structure.BoundingBox;

/**
 * One room of a Spectrite dungeon: a 9x9 cell of the dungeon's grid (walls shared with the neighbours, 7x7 inside),
 * floor at dy 0, ceiling at dy 6, which is also the floor of the cell above. Doors are 3 wide arches in the middle of
 * the walls, framed in the tier's Spectrite block; decoration stays out of the cross the doors open, so every door can
 * reach every other. The box goes 6 below the floor for the pits and the TNT, which only cells with no room under
 * them get.
 */
final class DungeonCell extends DungeonPiece {
    static final int SIZE = 8, HEIGHT = 6;
    static final int N = 1, E = 2, S = 4, W = 8;

    enum Role {
        ENTRANCE, LANDING, STAIRS, HALL, SPAWNER, TREASURE, TRAP_ARROWS, TRAP_FIRE, TRAP_POTION, TRAP_PIT, TRAP_TNT;

        boolean corridorTrap() { return this == TRAP_ARROWS || this == TRAP_FIRE || this == TRAP_POTION; }
        boolean spiral() { return this == ENTRANCE || this == LANDING || this == STAIRS; }
    }

    final Role role;
    final int doors, variant;
    private boolean guardianPlaced;

    DungeonCell(DungeonTier tier, int x0, int floor, int z0, int seed, Role role, int doors, int variant) {
        super(SpectralDungeons.CELL.get(), new BoundingBox(x0, floor - HEIGHT, z0, x0 + SIZE, floor + HEIGHT, z0 + SIZE), tier, floor, seed);
        this.role = role;
        this.doors = doors;
        this.variant = variant;
    }

    DungeonCell(CompoundTag tag) {
        super(SpectralDungeons.CELL.get(), tag);
        Role read = Role.HALL;
        for (Role r : Role.values()) if (r.name().equals(tag.getString("Role"))) read = r;
        role = read;
        doors = tag.getInt("Doors");
        variant = tag.getInt("Variant");
        guardianPlaced=tag.getBoolean("GuardianPlaced");
    }

    @Override
    protected void addAdditionalSaveData(net.minecraft.world.level.levelgen.structure.pieces.StructurePieceSerializationContext context, CompoundTag tag) {
        super.addAdditionalSaveData(context, tag);
        tag.putString("Role", role.name());
        tag.putInt("Doors", doors);
        tag.putInt("Variant", variant);
        tag.putBoolean("GuardianPlaced",guardianPlaced);
    }

    boolean door(int side) { return (doors & side) != 0; }

    /** Doors only along x (east, west) or only along z (north, south): a corridor the traps can line. */
    static boolean straight(int doors) {
        boolean ns = (doors & (N | S)) != 0, ew = (doors & (E | W)) != 0;
        return ns != ew;
    }

    @Override
    public void postProcess(WorldGenLevel level, StructureManager structures, ChunkGenerator generator, RandomSource random,
                            BoundingBox box, ChunkPos chunk, BlockPos pivot) {
        DungeonPalette p = palette();
        shell(level, box, p);
        for (int side : new int[] {N, E, S, W}) if (door(side)) doorway(level, box, p, side);
        switch (role) {
            case ENTRANCE, LANDING, STAIRS -> landing(level, box, p);
            case HALL -> hall(level, box, p, random);
            case SPAWNER -> spawnerRoom(level, box, p, random);
            case TREASURE -> treasure(level, box, p, random);
            case TRAP_ARROWS, TRAP_FIRE, TRAP_POTION -> corridorTrap(level, box, p, random);
            case TRAP_PIT -> pit(level, box, p);
            case TRAP_TNT -> tnt(level, box, p);
        }
        fragmentDetails(level,box);
        if(role==Role.HALL)themeDetails(level,box,p);
    }

    /** Distinct landmarks and interactable scenery make the profile recognizable beyond its palette. */
    private void themeDetails(WorldGenLevel level,BoundingBox box,DungeonPalette p) {
        switch(profile) {
            case CRYPT -> {for(int z:new int[]{2,6}){set(level,box,Blocks.CHISELED_STONE_BRICKS.defaultBlockState(),2,1,z);set(level,box,Blocks.SKELETON_SKULL.defaultBlockState(),2,2,z);}}
            case CATACOMBS -> {for(int[] spot:SPOTS){set(level,box,Blocks.COBWEB.defaultBlockState(),spot[0],3,spot[1]);set(level,box,Blocks.CRACKED_DEEPSLATE_BRICKS.defaultBlockState(),spot[0],1,spot[1]);}}
            case SANCTUM -> {for(int x:new int[]{2,6}){set(level,box,Blocks.CHISELED_QUARTZ_BLOCK.defaultBlockState(),x,1,2);set(level,box,DungeonFragmentBlocks.RELIQUARY.get().defaultBlockState(),x,2,2);}}
            case PRISMATIC_VAULT -> {for(int x:new int[]{1,7}){set(level,box,Blocks.TARGET.defaultBlockState(),x,2,2);set(level,box,Blocks.REDSTONE_LAMP.defaultBlockState(),x,3,2);}}
            case BASALT_BASTION -> {for(int z:new int[]{2,6})for(int y=1;y<=4;y++)set(level,box,Blocks.POLISHED_BASALT.defaultBlockState(),2,y,z);}
            case SOUL_CRUCIBLE -> {for(int[] spot:SPOTS){set(level,box,Blocks.SOUL_SAND.defaultBlockState(),spot[0],0,spot[1]);set(level,box,Blocks.SOUL_CAMPFIRE.defaultBlockState(),spot[0],1,spot[1]);}}
            case INFERNAL_ARCHIVE -> {for(int[] spot:SPOTS){set(level,box,Blocks.CHISELED_BOOKSHELF.defaultBlockState(),spot[0],1,spot[1]);set(level,box,Blocks.LECTERN.defaultBlockState(),spot[0],2,spot[1]);}}
            case PRISM_MINES -> {
                for(int z=1;z<8;z++)set(level,box,Blocks.RAIL.defaultBlockState(),4,1,z);
                for(int x:new int[]{1,7})for(int z:new int[]{2,6})set(level,box,com.samuel.spectrite.init.SpectriteBlocks.SPECTRITE_ORE.get().defaultBlockState(),x,2,z);
            }
            case DROWNED_ARCHIVE -> {
                for(int x:new int[]{2,6})for(int z=2;z<=6;z++)set(level,box,Blocks.WATER.defaultBlockState(),x,0,z);
                for(int[] spot:SPOTS)set(level,box,Blocks.SEA_LANTERN.defaultBlockState(),spot[0],4,spot[1]);
            }
            case THORN_CITADEL -> {
                for(int[] spot:SPOTS){set(level,box,Blocks.MOSS_BLOCK.defaultBlockState(),spot[0],1,spot[1]);set(level,box,Blocks.FLOWERING_AZALEA.defaultBlockState(),spot[0],2,spot[1]);}
            }
            case ECLIPSE_OBSERVATORY -> {
                for(int[] spot:SPOTS){set(level,box,Blocks.AMETHYST_BLOCK.defaultBlockState(),spot[0],1,spot[1]);set(level,box,Blocks.END_ROD.defaultBlockState(),spot[0],2,spot[1]);}
                set(level,box,Blocks.TINTED_GLASS.defaultBlockState(),4,HEIGHT,4);
            }
            case SOUL_NECROPOLIS,SEPULCHRAL_CHAINS -> {
                for(int[] spot:SPOTS){set(level,box,Blocks.CHAIN.defaultBlockState(),spot[0],4,spot[1]);set(level,box,Blocks.SOUL_LANTERN.defaultBlockState(),spot[0],3,spot[1]);}
            }
            case MONSTROUS_FOUNDRY,NETHERITE_COLOSSUS -> {
                for(int[] spot:SPOTS){set(level,box,Blocks.BLAST_FURNACE.defaultBlockState(),spot[0],1,spot[1]);set(level,box,DungeonFragmentBlocks.RELIQUARY.get().defaultBlockState(),spot[0],2,spot[1]);}
            }
            case SHATTERED_CATHEDRAL -> {
                for(int x:new int[]{1,7})for(int y=2;y<=4;y++)for(int z=2;z<=6;z++)set(level,box,Blocks.PURPLE_STAINED_GLASS.defaultBlockState(),x,y,z);
            }
            case ABYSSAL_PANOPTICON -> {
                for(int[] spot:SPOTS)for(int y=1;y<=3;y++)set(level,box,Blocks.IRON_BARS.defaultBlockState(),spot[0],y,spot[1]);
            }
            case CLOCKWORK_TOMB -> {
                set(level,box,Blocks.PISTON.defaultBlockState().setValue(net.minecraft.world.level.block.piston.PistonBaseBlock.FACING,Direction.EAST),1,1,4);
                set(level,box,Blocks.REDSTONE_LAMP.defaultBlockState(),1,3,4);
                set(level,box,Blocks.LIGHTNING_ROD.defaultBlockState(),7,1,4);
            }
            case MAGMA_LABYRINTH,CINDER_CISTERN -> {
                for(int x:new int[]{2,6})for(int z=2;z<=6;z++){set(level,box,Blocks.MAGMA_BLOCK.defaultBlockState(),x,-1,z);set(level,box,Blocks.TINTED_GLASS.defaultBlockState(),x,0,z);}
            }
            case HELLFIRE_CITADEL,INFERNAL_GAUNTLET -> {for(int[] spot:SPOTS)set(level,box,Blocks.SOUL_CAMPFIRE.defaultBlockState(),spot[0],1,spot[1]);}
            case OBSIDIAN_LABYRINTH -> {for(int[] spot:SPOTS)set(level,box,Blocks.CRYING_OBSIDIAN.defaultBlockState(),spot[0],2,spot[1]);}
            case CROWN_OF_RUIN,NETHER_ECLIPSE -> {for(int[] spot:SPOTS)set(level,box,Blocks.PURPUR_PILLAR.defaultBlockState(),spot[0],3,spot[1]);}
            default -> {}
        }
    }

    private void fragmentDetails(WorldGenLevel level,BoundingBox box) {
        // Keep door crosses, stairs and every trap plate clear. Each chunk uses deterministic coordinates.
        for(int[] corner:new int[][]{{1,1},{7,1},{1,7},{7,7}}) {
            if(chance(corner[0],0,corner[1],91,.35+.08*profile.difficulty())) {
                set(level,box,DungeonFragmentBlocks.BRICKS.get().defaultBlockState(),corner[0],0,corner[1]);
                if(profile.difficulty()>=3)set(level,box,DungeonFragmentBlocks.PILLAR.get().defaultBlockState(),corner[0],2,corner[1]);
            }
        }
        if(role==Role.HALL||role==Role.TREASURE||role==Role.SPAWNER) {
            for(int x:new int[]{2,6})for(int z:new int[]{2,6}) {
                set(level,box,(role==Role.TREASURE?DungeonFragmentBlocks.MOSAIC:DungeonFragmentBlocks.TILES).get().defaultBlockState(),x,0,z);
                if(role==Role.HALL&&chance(x,1,z,97,.22))set(level,box,DungeonFragmentBlocks.CLUSTER.get().defaultBlockState(),x,1,z);
            }
            if(role==Role.TREASURE)set(level,box,DungeonFragmentBlocks.RELIQUARY.get().defaultBlockState(),4,HEIGHT-1,4);
        }
    }

    // ------------------------------------------------------------------ shell
    private void shell(WorldGenLevel level, BoundingBox box, DungeonPalette p) {
        for (int x = 0; x <= SIZE; x++) {
            for (int z = 0; z <= SIZE; z++) {
                boolean edge = x == 0 || x == SIZE || z == 0 || z == SIZE;
                set(level, box, edge ? p.wall(noise(x, 0, z)) : p.floor(noise(x, 0, z)), x, 0, z);
                set(level, box, edge ? p.wall(noise(x, HEIGHT, z)) : p.ceiling(noise(x, HEIGHT, z)), x, HEIGHT, z);
                for (int dy = 1; dy < HEIGHT; dy++) {
                    if (edge) set(level, box, p.wall(noise(x, dy, z)), x, dy, z);
                }
            }
        }
        air(level, box, 1, 1, 1, SIZE - 1, HEIGHT - 1, SIZE - 1);
        // the four inner corners are the tier's pillar, the ceiling's edge a band of its Spectrite block
        for (int dy = 1; dy < HEIGHT; dy++) {
            for (int[] c : new int[][] {{1, 1}, {SIZE - 1, 1}, {1, SIZE - 1}, {SIZE - 1, SIZE - 1}}) set(level, box, p.pillar(), c[0], dy, c[1]);
        }
    }

    /** An arched opening 3 wide and 3 tall, framed in the tier's Spectrite block. */
    private void doorway(WorldGenLevel level, BoundingBox box, DungeonPalette p, int side) {
        BlockState trim = p.trim().defaultBlockState();
        for (int i = 2; i <= 6; i++) {
            for (int dy = 1; dy <= 4; dy++) {
                boolean wide=profile==DungeonProfile.SHATTERED_CATHEDRAL||profile==DungeonProfile.SANCTUM||profile==DungeonProfile.CROWN_OF_RUIN;
                boolean opening = wide?i>=2&&i<=6&&dy<=4:i>=3&&i<=5&&dy<=3;
                boolean frame = i == 2 || i == 6 || dy == 4;
                BlockState state = opening ? Blocks.AIR.defaultBlockState() : frame ? trim : null;
                if (state == null) continue;
                wallSet(level, box, side, i, dy, state);
            }
        }
        // rounded top corners
        boolean alongX = side == N || side == S;
        wallSet(level, box, side, 3, 3, stairs(p.trimStairs(), alongX ? Direction.WEST : Direction.NORTH, true));
        wallSet(level, box, side, 5, 3, stairs(p.trimStairs(), alongX ? Direction.EAST : Direction.SOUTH, true));
    }

    /** A block in the wall on {@code side}, {@code i} along it (0..8, from west or north). */
    private void wallSet(WorldGenLevel level, BoundingBox box, int side, int i, int dy, BlockState state) {
        switch (side) {
            case N -> set(level, box, state, i, dy, 0);
            case S -> set(level, box, state, i, dy, SIZE);
            case W -> set(level, box, state, 0, dy, i);
            default -> set(level, box, state, SIZE, dy, i);
        }
    }

    // ------------------------------------------------------------------ decoration
    /** The four free spots by the corners (next to the pillars), out of the doors' cross. */
    private static final int[][] SPOTS = {{2, 2}, {6, 2}, {2, 6}, {6, 6}};

    private void cornerDecor(WorldGenLevel level, BoundingBox box, DungeonPalette p, int x, int z, int kind) {
        switch (kind) {
            case 0 -> { // tomb: a Spectrite slab coffin with a skull
                set(level, box, slab(p.trimSlab(), false), x, 1, z);
                set(level, box, Blocks.SKELETON_SKULL.defaultBlockState().setValue(SkullBlock.ROTATION, noise(x, 2, z) % 16), x, 2, z);
            }
            case 1 -> set(level, box, Blocks.DECORATED_POT.defaultBlockState(), x, 1, z);
            case 2 -> set(level, box, Blocks.CANDLE.defaultBlockState().setValue(CandleBlock.CANDLES, 1 + noise(x, 1, z) % 4).setValue(CandleBlock.LIT, true), x, 1, z);
            case 3 -> set(level, box, Blocks.BONE_BLOCK.defaultBlockState(), x, 1, z);
            case 4 -> set(level, box, Blocks.COBWEB.defaultBlockState(), x, 1, z);
            default -> set(level, box, Blocks.BARREL.defaultBlockState(), x, 1, z);
        }
        if (chance(x, 5, z, 3, tier == DungeonTier.LEGENDARY ? 0.0 : 0.45)) set(level, box, Blocks.COBWEB.defaultBlockState(), x, 5, z);
    }

    /** A hanging lantern by one of the corners (on the crypt: candles instead, and fewer lanterns). */
    private void lights(WorldGenLevel level, BoundingBox box) {
        int[] spot = SPOTS[noise(0, 5, 0) % 4];
        if (tier != DungeonTier.BASIC || chance(0, 5, 0, 11, 0.35)) set(level, box, lantern(true), spot[0], 5, spot[1]);
        if (tier == DungeonTier.LEGENDARY) {
            int[] other = SPOTS[(noise(0, 5, 0) + 2) % 4];
            set(level, box, lantern(true), other[0], 5, other[1]);
        }
    }

    private void landing(WorldGenLevel level, BoundingBox box, DungeonPalette p) {
        // the spiral (DungeonSpiral) takes the centre; the corners get lights and a few relics
        for (int i = 0; i < SPOTS.length; i++) {
            int[] s = SPOTS[i];
            if (chance(s[0], 1, s[1], 5, 0.5)) cornerDecor(level, box, p, s[0], s[1], 2 + i % 2);
        }
        set(level, box, lantern(true), SPOTS[variant % 4][0], 5, SPOTS[variant % 4][1]);
    }

    private void hall(WorldGenLevel level, BoundingBox box, DungeonPalette p, RandomSource random) {
        switch (variant % 8) {
            case 0 -> { // crypt hall: tombs and urns
                for (int[] s : SPOTS) cornerDecor(level, box, p, s[0], s[1], noise(s[0], 1, s[1]) % 3);
            }
            case 1 -> { // library: bookshelves along the walls with no door
                for (int side : new int[] {N, E, S, W}) {
                    if (door(side)) continue;
                    for (int i = 2; i <= 6; i++) {
                        for (int dy = 1; dy <= 3; dy++) {
                            BlockState shelf = chance(i, dy, side, 7, 0.25) ? Blocks.CHISELED_BOOKSHELF.defaultBlockState() : Blocks.BOOKSHELF.defaultBlockState();
                            insideWall(level, box, side, i, dy, shelf);
                        }
                    }
                }
            }
            case 2 -> { // ossuary: bones and skulls
                for (int[] s : SPOTS) {
                    set(level, box, Blocks.BONE_BLOCK.defaultBlockState(), s[0], 1, s[1]);
                    set(level, box, Blocks.BONE_BLOCK.defaultBlockState(), s[0], 2, s[1]);
                    set(level, box, Blocks.SKELETON_SKULL.defaultBlockState().setValue(SkullBlock.ROTATION, noise(s[0], 3, s[1]) % 16), s[0], 3, s[1]);
                }
            }
            case 4 -> { // crystal workshop with a safe central crossing
                for(int[] spot:SPOTS) {
                    set(level,box,DungeonFragmentBlocks.BRICKS.get().defaultBlockState(),spot[0],1,spot[1]);
                    set(level,box,DungeonFragmentBlocks.CLUSTER.get().defaultBlockState(),spot[0],2,spot[1]);
                }
            }
            case 5 -> { // raised reliquary gallery: optional supplies behind visible bars
                for(int side:new int[]{N,E,S,W})if(!door(side)) {
                    insideWall(level,box,side,4,1,DungeonFragmentBlocks.RELIQUARY.get().defaultBlockState());
                    for(int i:new int[]{2,6})insideWall(level,box,side,i,2,Blocks.IRON_BARS.defaultBlockState());
                }
            }
            case 6 -> { // glowing specimen alcoves
                for(int[] spot:SPOTS) {
                    set(level,box,Blocks.TINTED_GLASS.defaultBlockState(),spot[0],1,spot[1]);
                    set(level,box,DungeonFragmentBlocks.CLUSTER.get().defaultBlockState(),spot[0],2,spot[1]);
                    set(level,box,Blocks.CHAIN.defaultBlockState(),spot[0],4,spot[1]);
                }
            }
            case 7 -> { // abandoned rest room: supplies, no spawn or trap plate in the central route
                for(int[] spot:SPOTS)set(level,box,slab(p.trimSlab(),false),spot[0],1,spot[1]);
                int[] corner=SPOTS[variant%4];
                createChest(level,box,random,at(corner[0],2,corner[1]),profile.spawnerLoot(),Blocks.BARREL.defaultBlockState());
            }
            default -> { // pillared hall
                for (int[] s : SPOTS) {
                    for (int dy = 1; dy < HEIGHT; dy++) set(level, box, dy == 1 || dy == HEIGHT - 1 ? p.trim().defaultBlockState() : p.pillar(), s[0], dy, s[1]);
                }
            }
        }
        // a forgotten barrel of supplies now and then
        if (chance(4, 1, 4, 13, 0.25)) {
            int[] s = SPOTS[(variant + 1) % 4];
            createChest(level, box, random, at(s[0], 1, s[1]), profile.spawnerLoot(), Blocks.BARREL.defaultBlockState());
        }
        lights(level, box);
    }

    /** Inside the room, against the wall on {@code side}: {@code i} along it (2..6). */
    private void insideWall(WorldGenLevel level, BoundingBox box, int side, int i, int dy, BlockState state) {
        switch (side) {
            case N -> set(level, box, state, i, dy, 1);
            case S -> set(level, box, state, i, dy, SIZE - 1);
            case W -> set(level, box, state, 1, dy, i);
            default -> set(level, box, state, SIZE - 1, dy, i);
        }
    }

    private void spawnerRoom(WorldGenLevel level, BoundingBox box, DungeonPalette p, RandomSource random) {
        set(level, box, p.trim().defaultBlockState(), 4, 1, 4);
        spawner(level, box, random, 4, 2, 4);
        // the loot of the spawner's keepers, right beside it
        chest(level, box, random, 5, 1, 5, Direction.SOUTH, profile.spawnerLoot());
        for (int[] s : SPOTS) if (chance(s[0], 1, s[1], 17, 0.5)) cornerDecor(level, box, p, s[0], s[1], 3 + noise(s[0], 1, s[1]) % 2);
        lights(level, box);
    }

    private void treasure(WorldGenLevel level, BoundingBox box, DungeonPalette p, RandomSource random) {
        int chests = switch (tier) { case BASIC -> 1; case INTERMEDIATE -> 2; case ADVANCED -> 3; case LEGENDARY -> 4; };
        Direction[] facing = {Direction.SOUTH, Direction.SOUTH, Direction.NORTH, Direction.NORTH};
        if (tier == DungeonTier.LEGENDARY) vault(level, box, p);
        int first = variant % 4;
        for (int i = 0; i < chests; i++) {
            int[] s = SPOTS[(first + i) % 4];
            chest(level, box, random, s[0], 1, s[1], facing[(first + i) % 4], profile.treasureLoot());
        }
        if (tier != DungeonTier.BASIC) {
            // one more chest that is not: a decoy over TNT, in the last free corner or, with all four taken, against a
            // wall with no door
            if (chests < 4) {
                int[] s = SPOTS[(first + chests) % 4];
                decoy(level, box, s[0], 1, s[1], facing[(first + chests) % 4]);
            } else if (!door(S)) decoy(level, box, 4, 1, SIZE - 1, Direction.NORTH);
            else if (!door(N)) decoy(level, box, 4, 1, 1, Direction.SOUTH);
            else if (!door(W)) decoy(level, box, 1, 1, 4, Direction.EAST);
            else if (!door(E)) decoy(level, box, SIZE - 1, 1, 4, Direction.WEST);
        }
        if (tier == DungeonTier.ADVANCED || tier == DungeonTier.LEGENDARY || profile==DungeonProfile.DROWNED_ARCHIVE) {
            set(level, box, p.trim().defaultBlockState(), 4, 1, 4);
            spawner(level, box, random, 4, 2, 4);
            if(profile.hasMonstrosity())guardian(level,box);
        }
        if(!profile.hasMonstrosity())guardian(level,box);
        BlockState infested = p.infested();
        if (infested != null) {
            // silverfish in the walls around the treasure
            for (int i = 1; i < SIZE; i++) {
                for (int dy = 1; dy < HEIGHT; dy++) {
                    for (int side : new int[] {N, E, S, W}) {
                        if (door(side) && i >= 2 && i <= 6 && dy <= 4) continue;
                        if (chance(i, dy, side, 19, 0.18)) wallSet(level, box, side, i, dy, infested);
                    }
                }
            }
        }
        lights(level, box);
    }

    /**
     * The treasure's keeper on the two hardest tiers, placed once with the room: a persistent, named Spectrite skeleton
     * (sanctum) or Spectrite wither skeleton (prismatic vault) in a full set of enchanted Spectrite chainmail.
     */
    private void guardian(WorldGenLevel level, BoundingBox box) {
        BlockPos pos = at(4, 1, 2);
        if (guardianPlaced||!box.isInside(pos)) return;
        String id="spectrite:spectrite_"+com.samuel.spectrite.souls.monster.DungeonChampions.species(profile);
        if (!(net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE.get(net.minecraft.resources.ResourceLocation.parse(id))
                .create(level.getLevel()) instanceof net.minecraft.world.entity.Mob mob)) return;
        mob.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, 0.0F, 0.0F);
        net.neoforged.neoforge.event.EventHooks.finalizeMobSpawn(mob, level, level.getCurrentDifficultyAt(pos),
            net.minecraft.world.entity.MobSpawnType.STRUCTURE, null);
        if (mob.isSpawnCancelled()) return;
        if(SpectralChainmail.wearsArmor(mob))SpectralChainmail.equipGuardian(mob, tier, profile);
        if(mob instanceof net.minecraft.world.entity.monster.Guardian)fill(level,box,Blocks.WATER.defaultBlockState(),2,1,1,6,2,3);
        if(!profile.hasMonstrosity())com.samuel.spectrite.souls.monster.DungeonChampions.mark(mob,profile);
        else mob.setCustomName(net.minecraft.network.chat.Component.translatable("entity.spectrite.dungeon_guardian."+tier.getSerializedName()));
        mob.setPersistenceRequired();
        level.addFreshEntityWithPassengers(mob);
        guardianPlaced=true;
    }

    /** The prismatic vault's treasure room: crying obsidian lining, a Spectrite glass floor over molten Spectrite. */
    private void vault(WorldGenLevel level, BoundingBox box, DungeonPalette p) {
        for (int i = 2; i <= 6; i++) {
            for (int dy = 1; dy < HEIGHT; dy++) {
                for (int side : new int[] {N, E, S, W}) {
                    if (door(side) && i >= 3 && i <= 5) continue;
                    if (dy >= 2) insideWall(level, box, side, i, dy, Blocks.CRYING_OBSIDIAN.defaultBlockState());
                }
            }
        }
        fill(level, box, SpectriteBlocks.MOLTEN_SPECTRITE.get().defaultBlockState(), 3, -1, 3, 5, -1, 5);
        fill(level, box, p.wall(0), 2, -2, 2, 6, -2, 6);
        fill(level, box, SpectriteBlocks.SPECTRITE_GLASS.get().defaultBlockState(), 3, 0, 3, 5, 0, 5);
    }

    // ------------------------------------------------------------------ traps
    /**
     * A corridor lined with dispensers at foot height, one behind each side plate: whoever steps on a plate by the
     * walls gets a volley (arrows, fire charges or splash potions, by the trap) from both sides. The middle line has no
     * plates: the careful can walk it.
     */
    private void corridorTrap(WorldGenLevel level, BoundingBox box, DungeonPalette p, RandomSource random) {
        boolean alongZ = (doors & (N | S)) != 0;
        var loot = switch (role) {
            case TRAP_FIRE -> SpectralDungeons.FIRE_TRAP;
            case TRAP_POTION -> profile.hasMonstrosity() ? net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.LOOT_TABLE,SpectralDungeons.id("dispensers/dungeon_monster_potions")) : SpectralDungeons.potionTrap(tier);
            default -> profile.hasMonstrosity() ? net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.LOOT_TABLE,SpectralDungeons.id("dispensers/dungeon_monster_arrows")) : SpectralDungeons.arrowTrap(tier);
        };
        BlockState trapFloor = p.trapFloor().defaultBlockState();
        for (int a = 1; a < SIZE; a++) {
            for (int b = 1; b < SIZE; b++) {
                // a runs along the corridor, b across it
                int x = alongZ ? b : a, z = alongZ ? a : b;
                boolean lane = b >= 3 && b <= 5;
                if (lane) {
                    set(level, box, trapFloor, x, 0, z);
                } else if (b == 1 || b == 7) {
                    for (int dy = 1; dy < HEIGHT; dy++) set(level, box, p.wall(noise(x, dy, z)), x, dy, z);
                } else {
                    // b 2 or 6: the dispenser walls, Spectrite trim with dispensers at foot height facing the lane
                    for (int dy = 1; dy < HEIGHT; dy++) set(level, box, dy == HEIGHT - 1 ? p.trim().defaultBlockState() : p.wall(noise(x, dy, z)), x, dy, z);
                }
            }
        }
        for (int a = 2; a <= 6; a++) {
            for (int side : new int[] {2, 6}) {
                int x = alongZ ? side : a, z = alongZ ? a : side;
                Direction facing = alongZ ? (side == 2 ? Direction.EAST : Direction.WEST) : (side == 2 ? Direction.SOUTH : Direction.NORTH);
                dispenser(level, box, random, x, 1, z, facing, loot);
                int plateB = side == 2 ? 3 : 5;
                plate(level, box, alongZ ? plateB : a, 1, alongZ ? a : plateB);
            }
        }
        set(level, box, lantern(true), alongZ ? 4 : 1, 5, alongZ ? 1 : 4);
    }

    /** A false floor (the tier's fake Spectrite block) over a pit: cobwebs, dripstone spikes, magma or molten Spectrite. */
    private void pit(WorldGenLevel level, BoundingBox box, DungeonPalette p) {
        BlockState real = p.trapFloor().defaultBlockState(), fake = p.fakeFloor().defaultBlockState();
        for (int x = 1; x < SIZE; x++) {
            for (int z = 1; z < SIZE; z++) {
                boolean hole = x >= 2 && x <= 6 && z >= 2 && z <= 6;
                set(level, box, hole ? fake : real, x, 0, z);
                for (int dy = -5; dy <= -1; dy++) {
                    if (!hole || dy == -5) set(level, box, p.wall(noise(x, dy, z)), x, dy, z);
                    else set(level, box, Blocks.AIR.defaultBlockState(), x, dy, z);
                }
            }
        }
        // what waits at the bottom, by tier: cobwebs, dripstone spikes, magma, molten Spectrite
        for (int x = 2; x <= 6; x++) {
            for (int z = 2; z <= 6; z++) {
                switch (tier) {
                    case BASIC -> { if ((x + z) % 2 == 0) set(level, box, Blocks.COBWEB.defaultBlockState(), x, -4, z); }
                    case INTERMEDIATE -> { if ((x + z) % 2 == 0) set(level, box, Blocks.POINTED_DRIPSTONE.defaultBlockState()
                        .setValue(PointedDripstoneBlock.TIP_DIRECTION, Direction.UP).setValue(PointedDripstoneBlock.THICKNESS, DripstoneThickness.TIP), x, -4, z); }
                    case ADVANCED -> set(level, box, Blocks.MAGMA_BLOCK.defaultBlockState(), x, -5, z);
                    case LEGENDARY -> set(level, box, SpectriteBlocks.MOLTEN_SPECTRITE.get().defaultBlockState(), x, -4, z);
                }
            }
        }
        // a way out for whoever survives the fall
        for (int dy = -4; dy <= -1; dy++) set(level, box, Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING, Direction.EAST), 2, dy, 4);
    }

    /**
     * Player plates in the middle of the room over a buried charge: the crypt's is vanilla TNT, the intermediate dungeon's
     * a Spectrite TNT (power 12) among vanilla TNT, the advanced and legendary ones' the same with contact Spectrite TNT
     * at the foot of the doorways' frames (a player who touches it sets it off).
     */
    private void tnt(WorldGenLevel level, BoundingBox box, DungeonPalette p) {
        BlockState real = p.trapFloor().defaultBlockState();
        for (int x = 2; x <= 6; x++) for (int z = 2; z <= 6; z++) set(level, box, real, x, 0, z);
        if (tier == DungeonTier.BASIC) {
            // the crypt's: one plate in the middle over four TNT, a cracked block beside it gives it away to the careful
            plate(level, box, 4, 1, 4);
            for (int x = 4; x <= 5; x++) for (int z = 4; z <= 5; z++) set(level, box, Blocks.TNT.defaultBlockState(), x, -1, z);
            set(level, box, Blocks.CRACKED_STONE_BRICKS.defaultBlockState(), 3, 0, 4);
        } else {
            // each plate powers the block it stands on, which lights what is under it: TNT around a Spectrite TNT,
            // so any plate sets the Spectrite one off within a second
            for (int x = 3; x <= 5; x++) {
                for (int z = 3; z <= 5; z++) {
                    plate(level, box, x, 1, z);
                    set(level, box, x == 4 && z == 4 ? SpectralExtras.TNT.get().defaultBlockState() : Blocks.TNT.defaultBlockState(), x, -1, z);
                }
            }
            if (tier != DungeonTier.INTERMEDIATE) {
                // contact Spectrite TNT at the foot of the doorways' frames: whoever runs out hugging the side touches it
                BlockState contact = SpectralExtras.CONTACT_TNT.get().defaultBlockState();
                for (int side : new int[] {N, E, S, W}) {
                    if (!door(side)) continue;
                    wallSet(level, box, side, 2, 1, contact);
                    if (tier == DungeonTier.LEGENDARY) wallSet(level, box, side, 6, 1, contact);
                }
            }
        }
        lights(level, box);
    }
}
