package com.samuel.spectrite.souls.dungeon;

import com.mojang.serialization.Codec;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.loot.LootTable;

/** Twenty-five encounters, independent of the four historical spawner block states. IDs are world-save contracts. */
public enum DungeonProfile implements StringRepresentable {
    CRYPT("spectrite_crypt",1,DungeonTier.BASIC,false,3,1,6,8,2,1,1,1,14),
    CATACOMBS("spectrite_catacombs",2,DungeonTier.INTERMEDIATE,false,4,2,8,11,4,2,1,1,16),
    SANCTUM("spectrite_sanctum",3,DungeonTier.ADVANCED,false,5,2,11,15,6,3,1,1,20),
    PRISMATIC_VAULT("spectrite_prismatic_vault",4,DungeonTier.LEGENDARY,false,6,3,25,30,12,10,4,3,24),
    PRISM_MINES("spectrite_prism_mines",1,DungeonTier.BASIC,false,4,1,10,13,3,2,1,0,18),
    DROWNED_ARCHIVE("spectrite_drowned_archive",2,DungeonTier.INTERMEDIATE,false,5,1,15,19,5,3,2,0,20),
    THORN_CITADEL("spectrite_thorn_citadel",3,DungeonTier.ADVANCED,false,4,3,10,13,7,4,2,1,18),
    ECLIPSE_OBSERVATORY("spectrite_eclipse_observatory",3,DungeonTier.ADVANCED,false,6,2,20,25,9,5,2,2,20),
    SOUL_NECROPOLIS("spectrite_soul_necropolis",4,DungeonTier.LEGENDARY,false,6,3,26,32,14,12,4,3,24),
    MONSTROUS_FOUNDRY("spectrite_monstrous_foundry",5,DungeonTier.LEGENDARY,false,7,4,40,46,24,12,4,4,28),
    CINDER_CISTERN("spectrite_cinder_cistern",2,DungeonTier.INTERMEDIATE,true,4,1,11,14,4,3,1,1,12),
    BASALT_BASTION("spectrite_basalt_bastion",3,DungeonTier.ADVANCED,true,5,2,17,21,7,4,2,1,14),
    SOUL_CRUCIBLE("spectrite_soul_crucible",3,DungeonTier.ADVANCED,true,4,3,11,14,8,5,2,2,12),
    INFERNAL_ARCHIVE("spectrite_infernal_archive",4,DungeonTier.LEGENDARY,true,6,3,25,31,14,12,4,4,16),
    NETHERITE_COLOSSUS("spectrite_netherite_colossus",4,DungeonTier.LEGENDARY,true,6,3,26,32,16,14,4,4,16),
    OBSIDIAN_LABYRINTH("spectrite_obsidian_labyrinth",5,DungeonTier.LEGENDARY,false,7,4,32,38,22,24,6,5,24),
    SHATTERED_CATHEDRAL("spectrite_shattered_cathedral",5,DungeonTier.LEGENDARY,false,7,4,30,36,20,22,6,5,26),
    ABYSSAL_PANOPTICON("spectrite_abyssal_panopticon",5,DungeonTier.LEGENDARY,false,7,4,34,40,24,24,6,6,24),
    CLOCKWORK_TOMB("spectrite_clockwork_tomb",5,DungeonTier.LEGENDARY,false,7,4,31,37,22,26,5,6,26),
    CROWN_OF_RUIN("spectrite_crown_of_ruin",5,DungeonTier.LEGENDARY,false,7,4,33,39,24,24,6,6,24),
    INFERNAL_GAUNTLET("spectrite_infernal_gauntlet",4,DungeonTier.LEGENDARY,true,6,3,27,33,18,22,5,5,16),
    MAGMA_LABYRINTH("spectrite_magma_labyrinth",4,DungeonTier.LEGENDARY,true,6,3,28,34,18,24,5,5,16),
    SEPULCHRAL_CHAINS("spectrite_sepulchral_chains",4,DungeonTier.LEGENDARY,true,6,4,25,31,20,24,6,5,16),
    HELLFIRE_CITADEL("spectrite_hellfire_citadel",5,DungeonTier.LEGENDARY,true,7,4,32,38,24,28,6,6,16),
    NETHER_ECLIPSE("spectrite_nether_eclipse",5,DungeonTier.LEGENDARY,true,7,4,34,40,24,28,6,6,16),
    PRISM_REEF("spectrite_prism_reef",2,DungeonTier.INTERMEDIATE,false,3,1,5,5,2,0,0,0,0),
    SUNKEN_BASILICA("spectrite_sunken_basilica",3,DungeonTier.ADVANCED,false,3,2,9,9,4,0,0,0,0),
    ABYSSAL_RELIQUARY("spectrite_abyssal_reliquary",4,DungeonTier.LEGENDARY,false,5,1,21,21,5,0,0,0,0),
    TIDAL_CITADEL("spectrite_tidal_citadel",4,DungeonTier.LEGENDARY,false,5,2,25,25,6,0,0,0,0),
    LEVIATHAN_SANCTUM("spectrite_leviathan_sanctum",5,DungeonTier.LEGENDARY,false,5,3,21,21,8,0,0,0,0);

    public static final Codec<DungeonProfile> CODEC=StringRepresentable.fromEnum(DungeonProfile::values);
    private final String name;
    private final int difficulty;
    final DungeonTier tier;
    final boolean nether;
    final DungeonLayout.Spec spec;

    DungeonProfile(String name,int difficulty,DungeonTier tier,boolean nether,int grid,int floors,int min,int max,
                   int spawners,int traps,int pits,int tnt,int depth) {
        this.name=name;this.difficulty=difficulty;this.tier=tier;this.nether=nether;
        this.spec=new DungeonLayout.Spec(grid,floors,min,max,spawners,traps,pits,tnt,depth);
    }
    @Override public String getSerializedName(){return name;}
    public ResourceLocation id(){return SpectralDungeons.id(name);}
    public int difficulty(){return difficulty;}
    public ResourceKey<Level> dimension(){return nether?Level.NETHER:Level.OVERWORLD;}
    public boolean ocean(){return ordinal()>=PRISM_REEF.ordinal();}
    public boolean hasMonstrosity(){return this==MONSTROUS_FOUNDRY;}
    /** Dimension-specific Spectrite inhabitants; difficulty is expressed through equipment and spawn limits. */
    public java.util.List<DungeonTier.SpawnerMob> mobs(){
        if(ocean())return java.util.List.of(mob("spectrite:spectrite_guardian",difficulty>=4?65:45),mob("spectrite:spectrite_drowned",35));
        java.util.ArrayList<DungeonTier.SpawnerMob> list=new java.util.ArrayList<>();
        if(nether) {
            list.add(mob("spectrite:spectrite_magma_cube",25));list.add(mob("spectrite:spectrite_blaze",20));
            list.add(mob("spectrite:spectrite_piglin",20));list.add(mob("spectrite:spectrite_zombified_piglin",10));
            if(difficulty>=3){list.add(mob("spectrite:spectrite_wither_skeleton",20));list.add(mob("spectrite:spectrite_zoglin",10));list.add(mob("spectrite:spectrite_hoglin",6));}
            if(difficulty>=4)list.add(mob("spectrite:spectrite_piglin_brute",15));
        } else {
            list.add(mob("spectrite:spectrite_zombie",20));list.add(mob("spectrite:spectrite_skeleton",20));
            list.add(mob("spectrite:spectrite_spider",12));list.add(mob("spectrite:spectrite_creeper",8));
            list.add(mob("spectrite:spectrite_silverfish",5));list.add(mob("spectrite:spectrite_slime",5));list.add(mob("spectrite:spectrite_zombie_villager",4));
            if(difficulty>=2){list.add(mob("spectrite:spectrite_husk",8));list.add(mob("spectrite:spectrite_endermite",3));list.add(mob("spectrite:spectrite_stray",10));list.add(mob("spectrite:spectrite_cave_spider",8));list.add(mob("spectrite:spectrite_witch",6));list.add(mob("spectrite:spectrite_pillager",8));list.add(mob("spectrite:spectrite_bogged",8));}
            if(difficulty>=3){list.add(mob("spectrite:spectrite_enderman",5));list.add(mob("spectrite:spectrite_phantom",3));if(this==SANCTUM||this==ECLIPSE_OBSERVATORY||this==CLOCKWORK_TOMB||this==CROWN_OF_RUIN)list.add(mob("spectrite:spectrite_breeze",12));list.add(mob("spectrite:spectrite_vindicator",10));list.add(mob("spectrite:spectrite_vex",4));}
            if(difficulty>=4){list.add(mob("spectrite:spectrite_evoker",4));list.add(mob("spectrite:spectrite_illusioner",4));list.add(mob("spectrite:spectrite_shulker",4));}
            if(this==DROWNED_ARCHIVE)list.add(mob("spectrite:spectrite_drowned",25));
            if(difficulty>=5)list.add(mob("spectrite:spectrite_ravager",3));
            // Large and world bosses are deliberately absent from repeatedly firing spawners.
        }
        return java.util.List.copyOf(list);
    }

    private static DungeonTier.SpawnerMob mob(String id,int weight){return new DungeonTier.SpawnerMob(net.minecraft.resources.ResourceLocation.parse(id),weight);}
    public ResourceKey<LootTable> spawnerLoot(){return loot("spawner");}
    public ResourceKey<LootTable> treasureLoot(){return loot("treasure");}
    private ResourceKey<LootTable> loot(String suffix){return ResourceKey.create(Registries.LOOT_TABLE,SpectralDungeons.id("chests/dungeons/"+name+"_"+suffix));}
    public static DungeonProfile legacy(DungeonTier tier){return values()[tier.ordinal()];}
    public static DungeonProfile read(String name,DungeonTier fallback){for(var p:values())if(p.name.equals(name))return p;return legacy(fallback);}
}
