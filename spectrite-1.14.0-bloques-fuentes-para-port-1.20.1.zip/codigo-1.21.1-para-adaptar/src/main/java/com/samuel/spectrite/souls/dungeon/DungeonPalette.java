package com.samuel.spectrite.souls.dungeon;

import com.samuel.spectrite.init.SpectriteBlocks;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/**
 * The materials of each dungeon tier. The plain walls are vanilla dungeon stone, aged by deterministic noise (the
 * same block wherever two pieces share it); every accent (door frames, corner pillars, stair slabs, trap floors) is the
 * tier's Spectrite block, so the deeper and harder the dungeon, the more it shines:
 * <ul>
 *   <li>basic, the crypt: stone bricks, mossy and cracked, a little cobblestone;</li>
 *   <li>intermediate, the catacombs: deepslate bricks and tiles;</li>
 *   <li>advanced, the sanctum: polished blackstone bricks, a little gilded blackstone;</li>
 *   <li>legendary, the prismatic vault: tuff bricks with the rainbow Spectrite bricks of the original mod.</li>
 * </ul>
 * A trap room's floor is the tier's Spectrite floor block; its false floors are the fake version of the same block.
 */
abstract class DungeonPalette {
    abstract BlockState wall(int noise);
    abstract BlockState floor(int noise);
    abstract BlockState ceiling(int noise);
    abstract BlockState pillar();
    abstract Block trim();
    abstract Block trimStairs();
    abstract Block trimSlab();
    abstract Block trimWall();
    abstract Block trapFloor();
    abstract Block fakeFloor();
    /** Infested walls around the treasure (null: none). */
    BlockState infested() { return null; }

    static DungeonPalette of(DungeonTier tier) {
        return switch (tier) {
            case BASIC -> CRYPT;
            case INTERMEDIATE -> CATACOMBS;
            case ADVANCED -> SANCTUM;
            case LEGENDARY -> VAULT;
        };
    }

    /** Each catalog entry has a separate material grammar; Spectrite trim retains the historical building IDs. */
    static DungeonPalette of(DungeonProfile profile) {
        DungeonPalette accent=of(profile.tier);
        Block[] theme=switch(profile) {
            case CRYPT,CATACOMBS,SANCTUM,PRISMATIC_VAULT -> null;
            case PRISM_MINES -> new Block[]{Blocks.ANDESITE,Blocks.POLISHED_ANDESITE,Blocks.COBBLESTONE,Blocks.CHISELED_STONE_BRICKS};
            case DROWNED_ARCHIVE -> new Block[]{Blocks.PRISMARINE_BRICKS,Blocks.DARK_PRISMARINE,Blocks.PRISMARINE,Blocks.SEA_LANTERN};
            case THORN_CITADEL -> new Block[]{Blocks.MOSSY_STONE_BRICKS,Blocks.MOSS_BLOCK,Blocks.MUD_BRICKS,Blocks.CHISELED_TUFF};
            case ECLIPSE_OBSERVATORY -> new Block[]{Blocks.END_STONE_BRICKS,Blocks.PURPUR_BLOCK,Blocks.SMOOTH_BASALT,Blocks.AMETHYST_BLOCK};
            case SOUL_NECROPOLIS -> new Block[]{Blocks.DEEPSLATE_TILES,Blocks.POLISHED_BLACKSTONE_BRICKS,Blocks.BONE_BLOCK,Blocks.CHISELED_POLISHED_BLACKSTONE};
            case MONSTROUS_FOUNDRY -> new Block[]{Blocks.POLISHED_BLACKSTONE_BRICKS,Blocks.DEEPSLATE_TILES,Blocks.SMOOTH_BASALT,Blocks.CHISELED_DEEPSLATE};
            case CINDER_CISTERN -> new Block[]{Blocks.NETHER_BRICKS,Blocks.RED_NETHER_BRICKS,Blocks.CRACKED_NETHER_BRICKS,Blocks.CHISELED_NETHER_BRICKS};
            case BASALT_BASTION -> new Block[]{Blocks.POLISHED_BASALT,Blocks.SMOOTH_BASALT,Blocks.BLACKSTONE,Blocks.GILDED_BLACKSTONE};
            case SOUL_CRUCIBLE -> new Block[]{Blocks.BONE_BLOCK,Blocks.POLISHED_BLACKSTONE,Blocks.SOUL_SOIL,Blocks.CHISELED_POLISHED_BLACKSTONE};
            case INFERNAL_ARCHIVE -> new Block[]{Blocks.RED_NETHER_BRICKS,Blocks.POLISHED_BLACKSTONE_BRICKS,Blocks.CHISELED_NETHER_BRICKS,Blocks.CRYING_OBSIDIAN};
            case PRISM_REEF -> new Block[]{Blocks.PRISMARINE,Blocks.PRISMARINE_BRICKS,Blocks.TUBE_CORAL_BLOCK,Blocks.SEA_LANTERN};
            case SUNKEN_BASILICA -> new Block[]{Blocks.QUARTZ_BRICKS,Blocks.DARK_PRISMARINE,Blocks.PRISMARINE_BRICKS,Blocks.CHISELED_QUARTZ_BLOCK};
            case ABYSSAL_RELIQUARY -> new Block[]{Blocks.DARK_PRISMARINE,Blocks.POLISHED_DEEPSLATE,Blocks.SCULK,Blocks.SEA_LANTERN};
            case TIDAL_CITADEL -> new Block[]{Blocks.PRISMARINE_BRICKS,Blocks.CUT_COPPER,Blocks.OXIDIZED_COPPER,Blocks.SEA_LANTERN};
            case LEVIATHAN_SANCTUM -> new Block[]{Blocks.DARK_PRISMARINE,Blocks.PRISMARINE_BRICKS,Blocks.CRYING_OBSIDIAN,Blocks.CHISELED_DEEPSLATE};
            case OBSIDIAN_LABYRINTH -> new Block[]{Blocks.OBSIDIAN,Blocks.POLISHED_BLACKSTONE,Blocks.CRYING_OBSIDIAN,Blocks.CHISELED_DEEPSLATE};
            case SHATTERED_CATHEDRAL -> new Block[]{Blocks.QUARTZ_BRICKS,Blocks.SMOOTH_QUARTZ,Blocks.CALCITE,Blocks.CHISELED_QUARTZ_BLOCK};
            case ABYSSAL_PANOPTICON -> new Block[]{Blocks.DEEPSLATE_BRICKS,Blocks.DARK_PRISMARINE,Blocks.SCULK,Blocks.CHISELED_DEEPSLATE};
            case CLOCKWORK_TOMB -> new Block[]{Blocks.COPPER_BLOCK,Blocks.WAXED_WEATHERED_CUT_COPPER,Blocks.TUFF_BRICKS,Blocks.WAXED_CHISELED_COPPER};
            case CROWN_OF_RUIN -> new Block[]{Blocks.END_STONE_BRICKS,Blocks.PURPUR_BLOCK,Blocks.CRYING_OBSIDIAN,Blocks.PURPUR_PILLAR};
            case INFERNAL_GAUNTLET -> new Block[]{Blocks.RED_NETHER_BRICKS,Blocks.POLISHED_BLACKSTONE,Blocks.NETHER_BRICKS,Blocks.CHISELED_NETHER_BRICKS};
            case MAGMA_LABYRINTH -> new Block[]{Blocks.SMOOTH_BASALT,Blocks.POLISHED_BASALT,Blocks.NETHERRACK,Blocks.GILDED_BLACKSTONE};
            case SEPULCHRAL_CHAINS -> new Block[]{Blocks.BONE_BLOCK,Blocks.POLISHED_BLACKSTONE_BRICKS,Blocks.SOUL_SOIL,Blocks.CHISELED_POLISHED_BLACKSTONE};
            case HELLFIRE_CITADEL -> new Block[]{Blocks.NETHER_BRICKS,Blocks.RED_NETHER_BRICKS,Blocks.CRYING_OBSIDIAN,Blocks.CHISELED_NETHER_BRICKS};
            case NETHER_ECLIPSE -> new Block[]{Blocks.OBSIDIAN,Blocks.POLISHED_BLACKSTONE,Blocks.SMOOTH_BASALT,Blocks.CHISELED_DEEPSLATE};
            case NETHERITE_COLOSSUS -> new Block[]{Blocks.DEEPSLATE_BRICKS,Blocks.POLISHED_BLACKSTONE,Blocks.SMOOTH_BASALT,Blocks.CHISELED_DEEPSLATE};
        };
        if(theme==null)return accent;
        return new DungeonPalette(){
            @Override BlockState wall(int n){return pick(n,65,s(theme[0]),23,s(theme[2]),12,s(accent.trim()));}
            @Override BlockState floor(int n){return pick(n,78,s(theme[1]),15,s(theme[0]),7,s(accent.trim()));}
            @Override BlockState ceiling(int n){return pick(n,80,s(theme[0]),20,s(theme[2]));}
            @Override BlockState pillar(){return s(theme[3]);}
            @Override Block trim(){return accent.trim();}
            @Override Block trimStairs(){return accent.trimStairs();}
            @Override Block trimSlab(){return accent.trimSlab();}
            @Override Block trimWall(){return accent.trimWall();}
            @Override Block trapFloor(){return accent.trapFloor();}
            @Override Block fakeFloor(){return accent.fakeFloor();}
        };
    }

    /** Weighted choice by noise: weights in percent, paired with the states. */
    static BlockState pick(int noise, Object... weighted) {
        int roll = Math.floorMod(noise, 100), sum = 0;
        for (int i = 0; i < weighted.length; i += 2) {
            sum += (Integer) weighted[i];
            if (roll < sum) return (BlockState) weighted[i + 1];
        }
        return (BlockState) weighted[weighted.length - 1];
    }

    static BlockState s(Block block) { return block.defaultBlockState(); }

    static final DungeonPalette CRYPT = new DungeonPalette() {
        @Override BlockState wall(int n) {
            return pick(n, 56, s(Blocks.STONE_BRICKS), 20, s(Blocks.MOSSY_STONE_BRICKS), 17, s(Blocks.CRACKED_STONE_BRICKS), 7, s(Blocks.COBBLESTONE));
        }
        @Override BlockState floor(int n) {
            return pick(n, 50, s(Blocks.STONE_BRICKS), 20, s(Blocks.COBBLESTONE), 15, s(Blocks.MOSSY_STONE_BRICKS), 10, s(Blocks.CRACKED_STONE_BRICKS), 5, s(Blocks.ANDESITE));
        }
        @Override BlockState ceiling(int n) {
            return pick(n, 65, s(Blocks.STONE_BRICKS), 20, s(Blocks.MOSSY_STONE_BRICKS), 15, s(Blocks.CRACKED_STONE_BRICKS));
        }
        @Override BlockState pillar() { return s(DungeonBlocks.CHISELED_STONE_BRICKS.get()); }
        @Override Block trim() { return DungeonBlocks.STONE_BRICKS.get(); }
        @Override Block trimStairs() { return DungeonBlocks.STONE_BRICK_STAIRS.get(); }
        @Override Block trimSlab() { return DungeonBlocks.STONE_BRICK_SLAB.get(); }
        @Override Block trimWall() { return DungeonBlocks.STONE_BRICK_WALL.get(); }
        @Override Block trapFloor() { return DungeonBlocks.STONE_BRICKS.get(); }
        @Override Block fakeFloor() { return DungeonBlocks.STONE_BRICKS_FAKE.get(); }
        @Override BlockState infested() { return s(Blocks.INFESTED_STONE_BRICKS); }
    };

    static final DungeonPalette CATACOMBS = new DungeonPalette() {
        @Override BlockState wall(int n) {
            return pick(n, 45, s(Blocks.DEEPSLATE_BRICKS), 20, s(Blocks.CRACKED_DEEPSLATE_BRICKS), 20, s(Blocks.DEEPSLATE_TILES), 10, s(Blocks.CRACKED_DEEPSLATE_TILES), 5, s(Blocks.CHISELED_DEEPSLATE));
        }
        @Override BlockState floor(int n) {
            return pick(n, 50, s(Blocks.DEEPSLATE_TILES), 20, s(Blocks.CRACKED_DEEPSLATE_TILES), 30, s(Blocks.POLISHED_DEEPSLATE));
        }
        @Override BlockState ceiling(int n) {
            return pick(n, 70, s(Blocks.DEEPSLATE_BRICKS), 30, s(Blocks.CRACKED_DEEPSLATE_BRICKS));
        }
        @Override BlockState pillar() { return s(Blocks.CHISELED_DEEPSLATE); }
        @Override Block trim() { return DungeonBlocks.DEEPSLATE_BRICKS.get(); }
        @Override Block trimStairs() { return DungeonBlocks.DEEPSLATE_BRICK_STAIRS.get(); }
        @Override Block trimSlab() { return DungeonBlocks.DEEPSLATE_BRICK_SLAB.get(); }
        @Override Block trimWall() { return DungeonBlocks.DEEPSLATE_BRICK_WALL.get(); }
        @Override Block trapFloor() { return DungeonBlocks.DEEPSLATE_TILES.get(); }
        @Override Block fakeFloor() { return DungeonBlocks.DEEPSLATE_TILES_FAKE.get(); }
        @Override BlockState infested() { return s(Blocks.INFESTED_DEEPSLATE); }
    };

    static final DungeonPalette SANCTUM = new DungeonPalette() {
        @Override BlockState wall(int n) {
            return pick(n, 60, s(Blocks.POLISHED_BLACKSTONE_BRICKS), 25, s(Blocks.CRACKED_POLISHED_BLACKSTONE_BRICKS), 11, s(Blocks.BLACKSTONE), 4, s(Blocks.GILDED_BLACKSTONE));
        }
        @Override BlockState floor(int n) {
            return pick(n, 50, s(Blocks.POLISHED_BLACKSTONE), 40, s(Blocks.POLISHED_BLACKSTONE_BRICKS), 10, s(Blocks.CRACKED_POLISHED_BLACKSTONE_BRICKS));
        }
        @Override BlockState ceiling(int n) {
            return pick(n, 75, s(Blocks.POLISHED_BLACKSTONE_BRICKS), 25, s(Blocks.CRACKED_POLISHED_BLACKSTONE_BRICKS));
        }
        @Override BlockState pillar() { return s(Blocks.CHISELED_POLISHED_BLACKSTONE); }
        @Override Block trim() { return DungeonBlocks.POLISHED_BLACKSTONE_BRICKS.get(); }
        @Override Block trimStairs() { return DungeonBlocks.POLISHED_BLACKSTONE_BRICK_STAIRS.get(); }
        @Override Block trimSlab() { return DungeonBlocks.POLISHED_BLACKSTONE_BRICK_SLAB.get(); }
        @Override Block trimWall() { return DungeonBlocks.POLISHED_BLACKSTONE_BRICK_WALL.get(); }
        @Override Block trapFloor() { return DungeonBlocks.POLISHED_BLACKSTONE_BRICKS.get(); }
        @Override Block fakeFloor() { return DungeonBlocks.POLISHED_BLACKSTONE_BRICKS_FAKE.get(); }
    };

    static final DungeonPalette VAULT = new DungeonPalette() {
        @Override BlockState wall(int n) {
            return pick(n, 45, s(Blocks.TUFF_BRICKS), 25, s(Blocks.POLISHED_TUFF), 10, s(Blocks.CHISELED_TUFF_BRICKS), 20, s(SpectriteBlocks.SPECTRITE_BRICKS.get()));
        }
        @Override BlockState floor(int n) {
            return pick(n, 45, s(Blocks.POLISHED_TUFF), 40, s(Blocks.TUFF_BRICKS), 15, s(DungeonBlocks.TUFF_BRICKS.get()));
        }
        @Override BlockState ceiling(int n) {
            return pick(n, 70, s(Blocks.TUFF_BRICKS), 30, s(Blocks.POLISHED_TUFF));
        }
        @Override BlockState pillar() { return s(SpectriteBlocks.SPECTRITE_BRICKS.get()); }
        @Override Block trim() { return DungeonBlocks.TUFF_BRICKS.get(); }
        @Override Block trimStairs() { return DungeonBlocks.TUFF_BRICK_STAIRS.get(); }
        @Override Block trimSlab() { return DungeonBlocks.TUFF_BRICK_SLAB.get(); }
        @Override Block trimWall() { return DungeonBlocks.TUFF_BRICK_WALL.get(); }
        @Override Block trapFloor() { return DungeonBlocks.TUFF_BRICKS.get(); }
        @Override Block fakeFloor() { return DungeonBlocks.TUFF_BRICKS_FAKE.get(); }
    };
}
