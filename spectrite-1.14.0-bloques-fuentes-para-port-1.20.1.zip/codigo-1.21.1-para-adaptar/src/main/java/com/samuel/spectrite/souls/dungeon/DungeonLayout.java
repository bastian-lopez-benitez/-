package com.samuel.spectrite.souls.dungeon;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.levelgen.structure.StructurePiece;
import org.jetbrains.annotations.Nullable;

/**
 * The plan of a Spectrite dungeon: floors of rooms on a square grid (8 blocks apart, 6 between floors), grown from
 * the room under the entrance shaft (or under the previous floor's stairs), joined into a tree with a few loops, then
 * given their roles. On every floor the stairs down are in the farthest room; on the last one the treasure is. The
 * spawners prefer dead ends; corridor traps need a straight room (doors on one axis only); pits and TNT need a room
 * with nothing under it.
 *
 * <pre>
 *   tier          grid  floors  rooms/floor  spawners  corridor traps  pits  TNT  depth of the first floor
 *   basic         3x3   1       6-8          2         1               1     1    14 under the surface
 *   intermediate  4x4   2       8-11         4         2               1     1    16
 *   advanced      5x5   2       11-15        6         3               1     1    20
 *   legendary     5x5   3       11-15        8         4               2     2    24
 * </pre>
 */
final class DungeonLayout {
    record Spec(int grid, int floors, int minCells, int maxCells, int spawners, int corridorTraps, int pits, int tnts, int depth) {}

    static Spec spec(DungeonTier tier) {
        return switch (tier) {
            case BASIC -> new Spec(3, 1, 6, 8, 2, 1, 1, 1, 14);
            case INTERMEDIATE -> new Spec(4, 2, 8, 11, 4, 2, 1, 1, 16);
            case ADVANCED -> new Spec(5, 2, 11, 15, 6, 3, 1, 1, 20);
            case LEGENDARY -> new Spec(5, 3, 11, 15, 8, 4, 2, 2, 24);
        };
    }

    private static final int[][] STEPS = {{0, -1, DungeonCell.N, DungeonCell.S}, {1, 0, DungeonCell.E, DungeonCell.W},
                                          {0, 1, DungeonCell.S, DungeonCell.N}, {-1, 0, DungeonCell.W, DungeonCell.E}};

    /**
     * The pieces of a dungeon whose shaft opens at ({@code cx}, {@code surface}, {@code cz}) ({@code surface} is the
     * standing height there), or null when it does not fit above the world's bottom.
     */
    @Nullable
    static List<StructurePiece> plan(DungeonTier tier, int cx, int surface, int cz, RandomSource random, int minY) {
        return plan(DungeonProfile.legacy(tier),cx,surface,cz,random,minY);
    }

    @Nullable
    static List<StructurePiece> plan(DungeonProfile profile,int cx,int surface,int cz,RandomSource random,int minY) {
        if(profile.ocean())return OceanMonumentRoom.plan(profile,cx,surface,cz,random);
        DungeonTier tier=profile.tier;
        Spec s = profile.spec;
        int g = s.grid(), floors = s.floors();
        int top = surface - s.depth();
        int bottom = top - (floors - 1) * DungeonCell.HEIGHT;
        if (bottom - DungeonCell.HEIGHT < minY + 2) return null;
        int seed = random.nextInt();
        int ei = random.nextInt(g), ej = random.nextInt(g);
        int ox = cx - (ei * DungeonCell.SIZE + 4), oz = cz - (ej * DungeonCell.SIZE + 4);

        boolean[][][] active = new boolean[floors][g][g];
        int[][][] doors = new int[floors][g][g];
        DungeonCell.Role[][][] roles = new DungeonCell.Role[floors][g][g];
        int[][][] dist = new int[floors][g][g];
        int[][] starts = new int[floors][];
        int si = ei, sj = ej;
        int[] treasureCell=null;
        for (int f = 0; f < floors; f++) {
            starts[f] = new int[] {si, sj};
            growStyled(profile,f,random, g, si, sj, s.minCells() + random.nextInt(s.maxCells() - s.minCells() + 1), active[f], doors[f]);
            distances(g, si, sj, active[f], doors[f], dist[f]);
            roles[f][si][sj] = f == 0 ? DungeonCell.Role.ENTRANCE : DungeonCell.Role.LANDING;
            int[] far = farthest(random, g, active[f], dist[f], roles[f]);
            if (far == null) return null;
            if (f < floors - 1) {
                roles[f][far[0]][far[1]] = DungeonCell.Role.STAIRS;
                si = far[0];
                sj = far[1];
            } else {
                roles[f][far[0]][far[1]] = DungeonCell.Role.TREASURE;
                treasureCell=far;
            }
        }
        // spawners: dead ends first, then the rooms farthest from where the floor is entered
        List<int[]> free = freeCells(floors, g, active, roles);
        free.sort(Comparator.comparingInt((int[] c) -> Integer.bitCount(doors[c[0]][c[1]][c[2]]) == 1 ? 0 : 1)
            .thenComparingInt(c -> -dist[c[0]][c[1]][c[2]]));
        int spawners = 0;
        for (int[] c : free) {
            if (spawners >= s.spawners()) break;
            if (dist[c[0]][c[1]][c[2]] < 2 && c[0] == 0) continue; // never right at the bottom of the entrance stairs
            roles[c[0]][c[1]][c[2]] = DungeonCell.Role.SPAWNER;
            spawners++;
        }
        // traps
        DungeonCell.Role[] corridor = switch (tier) {
            case BASIC -> new DungeonCell.Role[] {DungeonCell.Role.TRAP_ARROWS};
            case INTERMEDIATE -> new DungeonCell.Role[] {DungeonCell.Role.TRAP_ARROWS, DungeonCell.Role.TRAP_FIRE};
            default -> new DungeonCell.Role[] {DungeonCell.Role.TRAP_ARROWS, DungeonCell.Role.TRAP_FIRE, DungeonCell.Role.TRAP_POTION};
        };
        int placed = 0;
        for (int[] c : shuffled(random, freeCells(floors, g, active, roles))) {
            if (placed >= s.corridorTraps()) break;
            if (!DungeonCell.straight(doors[c[0]][c[1]][c[2]])) continue;
            roles[c[0]][c[1]][c[2]] = corridor[placed % corridor.length];
            placed++;
        }
        int pits = 0, tnts = 0;
        for (int[] c : shuffled(random, freeCells(floors, g, active, roles))) {
            boolean nothingBelow = c[0] == floors - 1 || !active[c[0] + 1][c[1]][c[2]];
            if (!nothingBelow) continue;
            if (pits < s.pits()) {
                roles[c[0]][c[1]][c[2]] = DungeonCell.Role.TRAP_PIT;
                pits++;
            } else if (tnts < s.tnts()) {
                roles[c[0]][c[1]][c[2]] = DungeonCell.Role.TRAP_TNT;
                tnts++;
            }
        }

        List<StructurePiece> pieces = new ArrayList<>();
        // deepest floor first: an upper room's floor is the ceiling of the room under it, and its own look wins
        for (int f = floors - 1; f >= 0; f--) {
            int y = top - f * DungeonCell.HEIGHT;
            for (int i = 0; i < g; i++) {
                for (int j = 0; j < g; j++) {
                    if (!active[f][i][j]) continue;
                    DungeonCell.Role role = roles[f][i][j] == null ? DungeonCell.Role.HALL : roles[f][i][j];
                    pieces.add(new DungeonCell(tier, ox + i * DungeonCell.SIZE, y, oz + j * DungeonCell.SIZE, seed, role, doors[f][i][j], random.nextInt(16)));
                }
            }
        }
        pieces.add(new DungeonEntrance(tier, cx, surface, cz, random.nextInt(4), seed));
        // the shaft from the surface down to the first room (walls from above that room's ceiling to under the entrance)
        pieces.add(new DungeonSpiral(tier, cx, cz, surface, top + 1, top + DungeonCell.HEIGHT + 1, surface - 2, seed));
        for (int f = 0; f < floors - 1; f++) {
            int[] st = starts[f + 1];
            int y = top - f * DungeonCell.HEIGHT;
            int scx = ox + st[0] * DungeonCell.SIZE + 4, scz = oz + st[1] * DungeonCell.SIZE + 4;
            pieces.add(new DungeonSpiral(tier, scx, scz, y + 1, y - DungeonCell.HEIGHT + 1, 1, 0, seed));
        }
        if(profile.hasMonstrosity() && treasureCell!=null) {
            int deepest=top-(floors-1)*DungeonCell.HEIGHT;
            int tx=ox+treasureCell[0]*DungeonCell.SIZE, tz=oz+treasureCell[1]*DungeonCell.SIZE;
            int arenaX=ox+g*DungeonCell.SIZE+16, arenaZ=tz-20;
            // A dedicated eastward passage joins the farthest treasure room to the boss arena.
            pieces.add(new DungeonGallery(tier,tx+DungeonCell.SIZE,deepest,tz+4,arenaX,seed));
            pieces.add(new DungeonArena(tier,arenaX,deepest,arenaZ,seed));
        }
        for(StructurePiece piece:pieces) if(piece instanceof DungeonPiece dungeon) dungeon.profile=profile;
        return pieces;
    }

    /** Profile-specific graph grammars: rings, branching tombs, radial halls, mine spines and serpentine gauntlets. */
    private static void growStyled(DungeonProfile profile,int floor,RandomSource random,int g,int si,int sj,int target,boolean[][] active,int[][] doors) {
        active[si][sj]=true;int count=1;target=Math.min(target,g*g);
        int[][] order=new int[g][g];order[si][sj]=1;
        while(count<target) {
            java.util.List<int[]> frontier=new java.util.ArrayList<>();
            for(int i=0;i<g;i++)for(int j=0;j<g;j++)if(active[i][j])for(int[] step:STEPS) {
                int ni=i+step[0],nj=j+step[1];if(ni>=0&&ni<g&&nj>=0&&nj<g&&!active[ni][nj])frontier.add(new int[]{i,j,ni,nj,step[2],step[3]});
            }
            if(frontier.isEmpty())break;
            int[] best=null;double score=Double.POSITIVE_INFINITY;int mid=g/2;
            for(int[] candidate:frontier) {
                int i=candidate[2],j=candidate[3];int a=(profile.ordinal()+floor)%2==0?i:j,b=(profile.ordinal()+floor)%2==0?j:i;
                int parent=order[candidate[0]][candidate[1]],edge=Math.min(Math.min(i,g-1-i),Math.min(j,g-1-j));
                int dx=Math.abs(i-mid),dz=Math.abs(j-mid);
                double priority=switch(profile) {
                    case CRYPT -> edge*14;
                    case CATACOMBS -> -parent*2;
                    case SANCTUM -> Math.min(dx,dz)*16;
                    case PRISMATIC_VAULT -> Math.abs(Math.max(dx,dz)-mid)*18+(dx+dz)*.2;
                    case PRISM_MINES -> dx*14+j*.2;
                    case DROWNED_ARCHIVE -> dz*13+i*.1;
                    case THORN_CITADEL -> (i%2==0&&j%2==0?12:0)+(dx+dz)*.3;
                    case ECLIPSE_OBSERVATORY -> Math.abs(i-j)*9+(i+j)*.1;
                    case SOUL_NECROPOLIS -> ((i+j)%3)*7-parent;
                    case MONSTROUS_FOUNDRY -> Math.min(i,g-1-i)*12+dz*.4;
                    case CINDER_CISTERN -> dx+dz;
                    case BASALT_BASTION -> Math.max(dx,dz)*4;
                    case SOUL_CRUCIBLE -> Math.abs(i+j-(g-1))*9;
                    case INFERNAL_ARCHIVE -> i%2*13+j*.6;
                    case NETHERITE_COLOSSUS -> Math.min(i,j)*7;
                    case OBSIDIAN_LABYRINTH -> (i*g+(i%2==0?j:g-1-j))*.8;
                    case SHATTERED_CATHEDRAL -> dx*18+j*.25;
                    case ABYSSAL_PANOPTICON -> Math.abs(dx-dz)*15;
                    case CLOCKWORK_TOMB -> ((i+j+floor)%2)*12-parent*.5;
                    case CROWN_OF_RUIN -> dx*dz*6;
                    case INFERNAL_GAUNTLET -> (j*g+(j%2==0?i:g-1-i))*.9;
                    case MAGMA_LABYRINTH -> Math.min(dx,dz)*8+((i+j)%2)*5;
                    case SEPULCHRAL_CHAINS -> j%2*12+i*.5;
                    case HELLFIRE_CITADEL -> edge*5+Math.abs(i-j)*3;
                    case NETHER_ECLIPSE -> Math.abs(i+j-2*mid)*7+(i*3+j)%4;
                    default -> 0;
                };
                priority+=random.nextDouble()*(2+profile.ordinal()%4);
                if(priority<score){score=priority;best=candidate;}
            }
            active[best[2]][best[3]]=true;order[best[2]][best[3]]=++count;
            doors[best[0]][best[1]]|=best[4];doors[best[2]][best[3]]|=best[5];
        }
        // Different loop densities retain retreat routes without making every plan the same maze.
        double loops=.025+(profile.ordinal()%6)*.025;
        for(int i=0;i<g;i++)for(int j=0;j<g;j++)if(active[i][j])for(int[] step:STEPS) {
            int ni=i+step[0],nj=j+step[1];if(ni>=0&&ni<g&&nj>=0&&nj<g&&active[ni][nj]&&random.nextDouble()<loops) {
                doors[i][j]|=step[2];doors[ni][nj]|=step[3];
            }
        }
    }

    /** Random growth from the start cell into {@code target} cells, each new one joined to the one it grew from. */
    private static void grow(RandomSource random, int g, int si, int sj, int target, boolean[][] active, int[][] doors) {
        List<int[]> cells = new ArrayList<>();
        active[si][sj] = true;
        cells.add(new int[] {si, sj});
        target = Math.min(target, g * g);
        int guard = 0;
        while (cells.size() < target && guard++ < 1000) {
            int[] from = cells.get(random.nextInt(cells.size()));
            int[] step = STEPS[random.nextInt(4)];
            int ni = from[0] + step[0], nj = from[1] + step[1];
            if (ni < 0 || nj < 0 || ni >= g || nj >= g || active[ni][nj]) continue;
            active[ni][nj] = true;
            doors[from[0]][from[1]] |= step[2];
            doors[ni][nj] |= step[3];
            cells.add(new int[] {ni, nj});
        }
        // a few loops, so it is not a pure tree
        for (int[] c : cells) {
            for (int[] step : STEPS) {
                int ni = c[0] + step[0], nj = c[1] + step[1];
                if (ni < 0 || nj < 0 || ni >= g || nj >= g || !active[ni][nj] || (doors[c[0]][c[1]] & step[2]) != 0) continue;
                if (random.nextFloat() < 0.15F) {
                    doors[c[0]][c[1]] |= step[2];
                    doors[ni][nj] |= step[3];
                }
            }
        }
    }

    private static void distances(int g, int si, int sj, boolean[][] active, int[][] doors, int[][] dist) {
        for (int[] row : dist) java.util.Arrays.fill(row, Integer.MAX_VALUE);
        ArrayDeque<int[]> queue = new ArrayDeque<>();
        dist[si][sj] = 0;
        queue.add(new int[] {si, sj});
        while (!queue.isEmpty()) {
            int[] c = queue.poll();
            for (int[] step : STEPS) {
                if ((doors[c[0]][c[1]] & step[2]) == 0) continue;
                int ni = c[0] + step[0], nj = c[1] + step[1];
                if (ni < 0 || nj < 0 || ni >= g || nj >= g || !active[ni][nj] || dist[ni][nj] != Integer.MAX_VALUE) continue;
                dist[ni][nj] = dist[c[0]][c[1]] + 1;
                queue.add(new int[] {ni, nj});
            }
        }
    }

    @Nullable
    private static int[] farthest(RandomSource random, int g, boolean[][] active, int[][] dist, DungeonCell.Role[][] roles) {
        int best = -1;
        List<int[]> found = new ArrayList<>();
        for (int i = 0; i < g; i++) {
            for (int j = 0; j < g; j++) {
                if (!active[i][j] || roles[i][j] != null || dist[i][j] == Integer.MAX_VALUE) continue;
                if (dist[i][j] > best) {
                    best = dist[i][j];
                    found.clear();
                }
                if (dist[i][j] == best) found.add(new int[] {i, j});
            }
        }
        return found.isEmpty() ? null : found.get(random.nextInt(found.size()));
    }

    /** Rooms with no role yet, as {floor, i, j}. */
    private static List<int[]> freeCells(int floors, int g, boolean[][][] active, DungeonCell.Role[][][] roles) {
        List<int[]> out = new ArrayList<>();
        for (int f = 0; f < floors; f++) for (int i = 0; i < g; i++) for (int j = 0; j < g; j++) {
            if (active[f][i][j] && roles[f][i][j] == null) out.add(new int[] {f, i, j});
        }
        return out;
    }

    private static List<int[]> shuffled(RandomSource random, List<int[]> list) {
        for (int i = list.size() - 1; i > 0; i--) {
            int k = random.nextInt(i + 1);
            int[] t = list.get(i);
            list.set(i, list.get(k));
            list.set(k, t);
        }
        return list;
    }

    private DungeonLayout() {}
}
