# Conservación para Minecraft 1.20.1

La entrega actual se ejecuta en Minecraft 1.21.1 con NeoForge. No es un binario para 1.20.1. El destino del port es Minecraft 1.20.1, Forge 47 y Java 17; requiere compilar y comprobar otra implementación de las integraciones del motor.

Los seis bloques de fragmentos tienen identificadores estables, modelos JSON de elementos clásicos, texturas animadas del JAR original, recetas sin componentes nuevos y botín normal. No dependen de Breeze, Bogged ni de entidades añadidas en 1.21. Su geometría y recetas se conservan en el proyecto y pueden trasladarse sin rediseñar el arte.

Fuentes: `DungeonFragmentBlocks.java`, `DungeonCell.java` y `tools/generate_hostile_variants_resources.py`. El script `tools/export_1_20_1_fragment_assets.py` exporta los modelos, texturas originales y datos de los seis bloques al formato de recursos de 1.20.1, conservando los mismos IDs. El paquete exportado contiene recursos: el registro Java y los generadores de estructuras todavía necesitan el port de Forge.

Durante el port hay que adaptar DeferredRegister/DeferredHolder a RegistryObject de Forge, eventos, red, atributos, recetas de la Forja del Réquiem, menús, datos de objetos (componentes de 1.21 → NBT de 1.20.1), serialización de estructuras y mixins. Breeze y Bogged necesitan entidades propias o sustitutos explícitos porque no existen en 1.20.1. No debe sustituirse el identificador de un bloque existente para resolver esto.

Antes de distribuir 1.20.1: compilar con Java 17, arrancar cliente y servidor Forge, verificar recetas/botín y mundos existentes, probar combate/proyectiles/transformación, y validar generación y mapas en ambas dimensiones. La verificación de 1.21.1 no demuestra compatibilidad con 1.20.1.
